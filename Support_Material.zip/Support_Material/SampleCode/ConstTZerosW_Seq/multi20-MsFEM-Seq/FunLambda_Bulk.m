% The thermal conductivity (lambda)
% uint "W cm^-1 K^-1"
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunLambda_Bulk(h,T)

% soil properties
b_1=-0.952;
b_2=-4.31;
b_3=6.00;
clay=0.249;
silt=0.73;
sand=0.021;
theta_s=0.547;
rho_b=1.2;

Lambda_dry=-0.56*theta_s+0.51;
alpha=0.67*clay+0.24;
beta=1.97*sand+1.87*rho_b-1.36*sand*rho_b-0.95;

% find water content
theta=FunWrc(h,T,1);

% calculate the thermal conducticity (effecitive)
y=0.01*(Lambda_dry+exp(beta-theta^(-alpha)));