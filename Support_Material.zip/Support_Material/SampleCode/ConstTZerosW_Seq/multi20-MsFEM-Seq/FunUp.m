% The upper BC of water potnetial, unit m
% based on Campbell and Norman, 1998
% Off_set: too much iteration,
% HF is the net surface energy flux,

function [E,H,T,HF]=FunUp(t,Head,Temp,dt,dh)

n=length(Head);
ht0=Head(n);
ht=Head(n);
t0=Temp(n);
t1=Temp(n);
ht2=Head(n-1);
t2=Temp(n-1);
error=0.001;
T=t1+1;

z=1.5; % m
L0=2260000;
rho_l=1000; % kg m^-3
z_0=0.0075; % m
rhoc_rho=1.127.*1005;
u=MyWind(t);

ta=MyAirTemp(t);
HR_a=MyAirHR(t);
rho_as=exp(19.84-4975.9./(ta+273.15))./1000;
rho_va=rho_as*HR_a;
check=1;
p=0;
    
while check
    % first calculate E
    Set_OffH=0;
    Set_OffT=0;
    
    rho_s=exp(19.84-4975.9./(t1+273.15))./1000;
    HR=exp(9.81.*0.018.*ht./8.3145./(t1+273.15));
    rho_vs=rho_s*HR;
    
    r_va=((log(z./z_0)).^2)./(0.16.*u);
    E=(rho_vs-rho_va)./r_va./rho_l;
    theta=(FunWrc(ht,t1,1).*dh-E.*dt)./dh-real(sqrt(FunH3(ht,t1,Set_OffH).*FunH3(ht2,t2,Set_OffH))).*(ht-ht2)./dh*dt./dh-real(sqrt(FunH4(ht,t1,Set_OffT).*FunH4(ht2,t2,Set_OffT))).*(t1-t2)./dh*dt./dh;
    ht_t=FunWrc(theta,t1,2);

    % Second Calculate t

    r_ha=((log(z./z_0)).^2)./(0.16.*u);
    LHS=MyR(t)-E.*rho_l.*L0+real(sqrt(FunDmv(ht_t,t1,Set_OffH)*FunDmv(ht2,t2,Set_OffH))).*(ht_t-ht2)./dh.*rho_l.*L0-real(sqrt(FunDtv(ht_t,t1,Set_OffT)*FunDtv(ht2,t2,Set_OffT))).*t2./dh.*rho_l.*L0+rhoc_rho.*ta./r_ha-real(sqrt(FunT4(ht_t,t1,Set_OffH).*FunT4(ht2,t2,Set_OffH))).*(ht_t-ht2)./dh-real(sqrt(FunT5(ht_t,t1,Set_OffH).*FunT5(ht2,t2,Set_OffH)))+real(sqrt(FunT3(ht_t,t1,Set_OffT).*FunT3(ht2,t2,Set_OffT))).*t2./dh;
    RHS=real(sqrt(FunT3(ht_t,t1,Set_OffT).*FunT3(ht2,t2,Set_OffT)))./dh+rhoc_rho./r_ha-real(sqrt(FunDtv(ht_t,t1,Set_OffT)*FunDtv(ht2,t2,Set_OffT)))./dh.*rho_l.*L0;
    t1_t=LHS./RHS;
    
    HF=MyR(t)-E.*rho_l.*L0+real(sqrt(FunDmv(ht_t,t1,Set_OffH)*FunDmv(ht2,t2,Set_OffH))).*(ht_t-ht2)./dh.*rho_l.*L0+real(sqrt(FunDtv(ht_t,t1,Set_OffT)*FunDtv(ht2,t2,Set_OffT))).*(t1_t-t2)./dh.*rho_l.*L0-rhoc_rho.*(t1_t-ta)./r_ha;
    %-real(sqrt(FunT4(ht_t,t1,Set_OffH).*FunT4(ht2,t2,Set_OffH))).*(ht_t-ht2)./dh-real(sqrt(FunT5(ht_t,t1,Set_OffH).*FunT5(ht2,t2,Set_OffH)))-real(sqrt(FunT3(ht_t,t1,Set_OffT).*FunT3(ht2,t2,Set_OffT))).*(t1_t-t2)./dh;
      
    %max(abs((ht_t-ht)./ht),abs((t1_t-t1)./t1))
    
    if max(abs((ht_t-ht)./ht),abs((t1_t-t1)./t1))<error
        H=ht_t; T=t1_t; 
        check=0;
    else
        ht=ht_t; t1=t1_t;
        check=1;
    end

end
   