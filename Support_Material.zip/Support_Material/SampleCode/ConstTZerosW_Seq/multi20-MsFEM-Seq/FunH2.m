% The coefficients of pthetapt in Water equation [19] Nassar 
% we defined here as H2
% The unit is "oC^-1"
% H2 is the same as the coefficient, i.e. Hydraulic_2

function y=FunH2(h,T)

% soil properties
theta_s=0.547;
rho_w=1.000; %"g cm^-3"
T0=25; % "oC"

% prelim parameters for each partitions
theta=FunWrc(h,T,1);
theta_a=theta_s-theta;
beta=2.09e-3; % (K^-1)

% potential-temperature correction (ask Horton where the equation [22] Heitman should applied)
ht=h;
Tt=T+273.5;

% calculate necessary quantities
%rho_s=exp(19.84-4975.9./(T+273.5))./1000; %"Kg m^-3"
%HR=exp(9.81.*0.018.*ht./8.3145./(T+273.15));
rho_s=1.0e-6.*exp(19.84-4975.9./Tt);    % g/cm^3
HR=exp(2.1238e-04.*ht./Tt);
%rho_v=rho_s.*HR;

prho_spT=rho_s.*4975.9./(Tt.^2);

%{
there are some old code taking into accout of \partial h\partial t,
including the change of h with respect to t

    % calculate the change of potential v.s the change of temperature (ASK Horton)
    % first reduce the potential to reference value
    h0=ht.*exp(beta.*(T-T0));
    pPhi_mpT=-beta.*h0.*exp(-beta.*(T-T0));
    
    pHRpT=HR.*(9.81.*0.018.*pPhi_mpT./8.3145./(T+273.15)-9.81.*0.018.*ht./8.3145./((T+273.15).^2));

%}

pHRpT=-HR.*2.1238e-04.*ht./(Tt.^2);   % 1/K


% finially the partial derivaitve part.
prho_vpT=rho_s.*pHRpT+prho_spT.*HR;

y=theta_a.*prho_vpT./rho_w;       % 1/K
