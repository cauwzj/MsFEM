% The thermal conductivity (lambda)
% uint "W cm^-1 K^-1"
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunLambda(h,T)

% soil properties
b_1=-0.952;
b_2=-4.31;
b_3=6.00;

% find water content
theta=FunWrc(h,T,1);

% calculate the thermal conducticity (effecitive)
y=0.01*(b_1+b_2.*theta+b_3.*(theta.^0.5));



