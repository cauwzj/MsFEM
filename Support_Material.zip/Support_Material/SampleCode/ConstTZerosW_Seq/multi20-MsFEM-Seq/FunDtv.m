% The diffusivity of (conductivity of vapour due to temperature or potential)
% For Dtv, in unit of "cm^2/s/K"
% refer to Nassar and Horton 1997 and Heitman 2008


function y=FunDtv(h,T)


% soil properties
theta_s=0.547;
clay=0.249;
% from potential to water content
theta=FunWrc(h,T,1);

% prelim parameters
beta=2.09e-3;            % (K^-1)
T0=25; %oC

phi=theta_s;
rho_w=1.000;             %(g/cm^3)

% potential-temperature correction (ask Horton where the equation [22] Heitman should applied)
ht=h;
Tt=T+273.15;
    
%D=2.3500e-05.*real((Tt./273.15).^1.75);  % m^2/s
D=0.23500.*abs((Tt./273.15).^1.75);      % cm^2/s
Omega=abs((phi-theta).^(2./3));
theta_a=phi-theta;


% water vapour properties
% rho_s=exp(19.84-4975.9./(T+273.15))./1000;
%HR=exp(9.81.*0.018.*ht./8.3145./(T+273.15));
rho_s=1.0e-6.*exp(19.84-4975.9./Tt);    % g/cm^3
HR=exp(2.1238e-04.*ht./Tt);
prho_spT=rho_s.*4975.9./(Tt.^2);

%{
there are some old code taking into accout of \partial h\partial t,
including the change of h with respect to t

first ignore this part and try a simple one
    % calculate pPhi_mpT see Heitman [19]
    % calculate the change of potential v.s the change of temperature (ASK Horton)
    % first reduce the potential to reference value
    h0=ht.*exp(beta.*(T-T0));
    pPhi_mpT=-beta.*h0.*exp(-beta.*(T-T0));
    %pPhi_mpT=-beta.*ht.*exp(-beta.*(T-T0));

    pHRpT=HR.*(9.81.*0.018.*pPhi_mpT./8.3145./(T+273.15)-9.81.*0.018.*ht./8.3145./((T+273.15).^2));
    

    % calculate Dtv
    y=eta.*D.*Omega.*theta_a.*(HR.*prho_spT+rho_s.*pHRpT)./rho_w;
%}


pHRpT=-HR.*2.1238e-04.*ht./(Tt.^2);
eta=8+6.*theta-7.*exp(-((1+2.6./sqrt(clay)).*theta).^4);

y=eta.*D.*Omega.*theta_a.*(HR.*prho_spT+rho_s.*pHRpT)./rho_w;

