% The soil volumetric heat capacity, unit "J/cm^3/K"
% For water potential, uint "cm"
% h potential "m", <0
% T temperature "oC"
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunCs(h,T)

% soil properties
theta_s=0.547;
sand=0.022;
silt=0.729;
clay=0.249;
som=0.044;
rho_b=1.2; % g cm^-3
rho_l=1.0; %"g cm^-3"

% prelim parameters for each partitions
c_o=1.900; %"J g^-1 K-1"
c_m=0.730; %"J g^-1 K-1"
c_v=1.864; %"J g^-1 K-1"
c_l=4.187; %"J g^-1 K-1"

% weight of each partition
phi_o=som;
phi_m=sand+silt+clay;

% potential-temperature correction
ht=h;
Tt=T+273.15;

theta=FunWrc(h,T,1);
theta_a=theta_s-theta;
rho_vs=1.0e-6.*exp(19.84-4975.9./Tt);         %"g cm^-3"
% HR=exp(9.81.*0.018.*ht./8.3145./(T+273.15));
HR=exp(2.1238e-04.*ht./Tt);
rho_v=rho_vs.*HR;                       %"g cm^-3"  

y=rho_b.*(c_o.*phi_o+c_m.*phi_m)+c_v.*rho_v.*theta_a+c_l.*rho_l.*theta;

