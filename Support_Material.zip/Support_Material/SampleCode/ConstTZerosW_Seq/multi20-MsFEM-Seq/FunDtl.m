% The hydraulic conductivity (diffusivity) of liquid water due to temperature change
% For KpPhi_mpT, in unit of "cm^2 s^-1 T^-1"
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunDtl(h,T)

% soil properties
theta_s=0.547;
K_s=0.0038;              % cm/s
b=6.53;
Sa=2.4415e+06;           % cm^2/cm^3

% from potential to water content
theta=FunWrc(h,T,1);

% prelim parameters
beta=2.09e-3;            % (K^-1)

% Calculate the hydraulic conductivity at T_0
% Assume T_0=25oC
KT0=K_s.*((theta./theta_s).^(2.*b+3));
T0=25; % (oC)

% Do the temperature correction
% the viscosity ~ temperature is from Bingham [2.8]
muT=(1./(0.021482.*(T-8.435+(T.^2-16.87.*T+8149.5492).^0.5)-1.2))./1000; % (N s/m^2)
muT_0=(1./(0.021482.*(T0-8.435+(T0.^2-16.87.*T0+8149.5492).^0.5)-1.2))./1000; % (N s/m^2)
K=KT0.*muT_0./muT;

GainFactor=4;

% calculate the change of potential v.s the change of temperature (ASK Horton)
% first reduce the potential to reference value
% pPhi_mpT=-beta.*h.*exp(-beta.*(T-T0));

kkk=Sa/981*1.4550e-06;

% the calculated hydraulic conductivity (diffusivity)
y=K.*kkk.*GainFactor;


