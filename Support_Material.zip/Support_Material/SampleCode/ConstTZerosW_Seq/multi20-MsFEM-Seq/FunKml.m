% The hydraulic conductivity of liquid water due to water potential (<0)
% For Kml, in unit of "m s^-1"
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunKml(h,T)

% soil properties
theta_s=0.547;
K_s=3.8e-3; % (cm/s)
b=6.53;
% from potential to water content
theta=FunWrc(h,T,1);
% Calculate the hydraulic conductivity at T_0
% Assume T_0=25oC
KT0=K_s.*((theta./theta_s).^(2.*b+3));
T0=25; % (oC)
% Do the temperature correction
% the viscosity ~ temperature is from Bingham [2.8]
muT=(1./(0.021482.*(T-8.435+(T.^2-16.87.*T+8149.5492).^0.5)-1.2))./1000; % (N s/m^2)
muT_0=(1./(0.021482.*(T0-8.435+(T0.^2-16.87.*T0+8149.5492).^0.5)-1.2))./1000; % (N s/m^2)
y=KT0.*muT_0./muT;


