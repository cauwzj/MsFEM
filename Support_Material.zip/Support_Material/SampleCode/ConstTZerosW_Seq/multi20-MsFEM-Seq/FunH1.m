
% Hydraulic_1
% we defined here as H1
% The unit is "cm^-1"
% H1 is not as same as the coefficient, but we multiply it by the water
% capacity, thus 
% $H_1=[1-\frac{\rho_v}{\rho_w}]\frac{\paritial\theta}{\partial\Phi}+\frac{\theta_a}{\rho_w}\frac{\partial \rho_v}{\partial\Phi_m}$

function y=FunH1(h,T)

% soil properties
theta_s=0.547;
rho_w=1.000; %"g cm^-3"

% prelim parameters for each partitions
theta=FunWrc(h,T,1);
theta_a=theta_s-theta;

% potential-temperature correction (ask Horton where the equation [22] Heitman should applied)
ht=h;
Tt=T+273.15;

% calculate necessary quantities
%rho_vs=exp(19.84-4975.9./(T+273.5))./1000; %"Kg m^-3"
%HR=exp(9.81.*0.018.*ht./8.3145./(T+273.15));
rho_vs=1.0e-6.*exp(19.84-4975.9./Tt);    % g/cm^3
HR=exp(2.1238e-04.*ht./Tt);
rho_v=rho_vs.*HR;
prho_vpPhi_m=rho_v.*2.1238e-04./Tt; % uint" g/cm^3 / cm"

y=(1-rho_v./rho_w).*FunWaCapa(h,T,1)+(theta_a./rho_w).*prho_vpPhi_m;  % uint "1/cm"
