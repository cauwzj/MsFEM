% The water capacity
% uint "cm^-1"
% mode 1: potention to Capa
% mode 2: VWC to Capa
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunWaCapa(input,T,mode)

% soil properties
theta_s=0.547;
b=6.53;
% prelim parameters
Phi_e=-13.0; % (cm)
T0=25; beta=2.09e-3;
if mode==1
    h=min(input,-13.0);
    h=max(h,-3.0e10);
    ht=h;
%    ht=h.*exp(beta.*(T-T0));
elseif mode==2
    theta=input;
    ht=Phi_e.*abs(((theta./theta_s).^(-b)));
    ht=min(ht,-13.0);
    ht=max(ht,-3.0e10);
end
y=-theta_s.*abs((ht./Phi_e).^(-1./b-1))./b./Phi_e;