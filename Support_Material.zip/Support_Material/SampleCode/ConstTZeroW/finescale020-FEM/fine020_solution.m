% USDA example 1
% constant temperature (may need to low the water content)

clear all
close all
clc

H=100; % unit cm
T=10*24*3600; % the input is "day", but the 
nh=20; % number of spatial nodes
dt_0=1; % unit of second
dt_max=1800;

dh=H/nh;
dt=dt_0;
TotalT=0;
TotalNodeC=(nh+1)*(nh+1);
epsilon=0.01;
theta_ini=0.2;
tmpr_ini=25;
head_ini=FunWrc(theta_ini,tmpr_ini,2);

% prelim parameters
rho_l=1.000;    % "g cm^-3"
L_0=2270;       % "J g^-1"
c_v=1.864;      % "J g^-1 K-1"
c_l=4.187;      % "J g^-1 K-1"
T_0=25;          % "oC"
theta_s=0.547;
TupWindL=zeros(4,2);
TupWindV=zeros(4,2);

% assume boundary conditions
TUp=30;
TDown=20;

% ----------------- here we need to load the random field ---------------
% RF_Ks=ones(nh+1);
% RF_La=ones(nh+1);
 load RF_Ks.mat
 load RF_La.mat
 
 RF_Ks1=zeros(nh+1,nh+1);
 RF_La1=zeros(nh+1,nh+1);
  
 MsRatio=100/nh;
 
 for i=1:nh+1
     for j=1:nh+1
         RF_Ks1(i,j)=RF_Ks((i-1)*MsRatio+1,(j-1)*MsRatio+1);
         RF_La1(i,j)=RF_La((i-1)*MsRatio+1,(j-1)*MsRatio+1);
     end
 end
 
 RF_Ks=RF_Ks1;
 RF_La=RF_La1;

% ----------------- multiscale initialization ---------------------------

HeadC=zeros(nh+1,nh+1);     % from bottom to top (Coarse)
TempC=zeros(nh+1,nh+1);
ThetaC=zeros(nh+1,nh+1);

for i=1:nh+1
    for j=1:nh+1
        HeadC(i,j)=head_ini;
        TempC(i,j)=tmpr_ini;
        ThetaC(i,j)=theta_ini;
    end
end
for j=1:nh+1
    TempC(1,j)=TDown;
    TempC(nh+1,j)=TUp;
end

Head=HeadC;                 % from bottom to top (fine)
Temp=TempC;
Theta=ThetaC;

% ------------------ the multiscale basis --------------------------------
dhf=dh;
dhf2=dhf.*dhf;

MsEleArray=ones(nh*nh,4);
MsNodeArray=zeros((nh+1),(nh+1),2);
for i=1:nh+1 
    for j=1:nh+1
        MsNodeArray(i,j,1)=(i-1)*(nh+1)+j;
        MsNodeArray(i,j,2)=0+1*(i==1)+2*(i==nh+1);
    end
end 
EleIndex=0;
for i=1:nh 
    for j=1:nh
        EleIndex=EleIndex+1;
        MsEleArray(EleIndex,1)=MsNodeArray(i,j,1);
        MsEleArray(EleIndex,2)=MsNodeArray(i,j+1,1);
        MsEleArray(EleIndex,3)=MsNodeArray(i+1,j+1,1);
        MsEleArray(EleIndex,4)=MsNodeArray(i+1,j,1);
    end
end 

% ------------------ reserve some parameter matrix -----------------------

KmlC=zeros(nh+1,nh+1);
DtlC=zeros(nh+1,nh+1);
DmvC=zeros(nh+1,nh+1);
DtvC=zeros(nh+1,nh+1);
LamC=zeros(nh+1,nh+1);
H1C=zeros(nh+1,nh+1);
H2C=zeros(nh+1,nh+1);
T1C=zeros(nh+1,nh+1);
T2C=zeros(nh+1,nh+1);

% ------------------ temp vars for iterations -----------------------

HeadCt=HeadC;
TempCt=TempC;
HeadCtt=HeadC;
TempCtt=TempC;
HeadCpp=HeadC;
TempCpp=TempC;

% install the intial condition
SaveThreshold=0;
TSindex=1;
ThetaSave=zeros((nh+1)*(nh+1),241);
HeadSave=zeros((nh+1)*(nh+1),241);
TmprSave=zeros((nh+1)*(nh+1),241);
ElaspSave=zeros(241,1);

% begin the time domain iteration, Total time is the stop citerion
while TotalT<T
    
    tic
    
    p=0;
    HeadCtt=HeadC;
    TempCtt=TempC;  
    
    % ----------- parameter setting ------------------------------
    for i=1:nh+1 
        for j=1:nh+1
            KmlC(i,j)=RF_Ks(i,j).*FunKml(HeadC(i,j),TempC(i,j));
            DtlC(i,j)=RF_Ks(i,j).*FunDtl(HeadC(i,j),TempC(i,j));
            DmvC(i,j)=FunDmv(HeadC(i,j),TempC(i,j));
            DtvC(i,j)=FunDtv(HeadC(i,j),TempC(i,j));
            LamC(i,j)=RF_La(i,j).*FunLambda_Bulk(HeadC(i,j),TempC(i,j));
            H1C(i,j)=FunH1(HeadC(i,j),TempC(i,j));
            H2C(i,j)=FunH2(HeadC(i,j),TempC(i,j));
            T1C(i,j)=FunT1(HeadC(i,j),TempC(i,j));
            T2C(i,j)=FunT2(HeadC(i,j),TempC(i,j));
        end
    end
    
    % ------------ start to assemble the finite element method ---------------- 

    EleIndex=0;
    
    A=sparse(2*TotalNodeC,2*TotalNodeC);
    B=sparse(2*TotalNodeC,1);
    for i=1:nh
        for j=1:nh
            
            % -------------------- preparation part --------------------

            EleIndex=EleIndex+1;
            NodeIndex1=MsEleArray(EleIndex,1);
            NodeIndex2=MsEleArray(EleIndex,2);
            NodeIndex3=MsEleArray(EleIndex,3);
            NodeIndex4=MsEleArray(EleIndex,4);
            
            % read the basis function and gradient matrix here
            
                        
            % mean soil property across the cross element
            % Arithmetic mean?? Geometical mean?
            
            KmlAve=(KmlC(i,j)*KmlC(i+1,j)*KmlC(i,j+1)*KmlC(i+1,j+1))^0.25;
            DtlAve=(DtlC(i,j)*DtlC(i+1,j)*DtlC(i,j+1)*DtlC(i+1,j+1))^0.25;
            DmvAve=(DmvC(i,j)*DmvC(i+1,j)*DmvC(i,j+1)*DmvC(i+1,j+1))^0.25;
            DtvAve=(DtvC(i,j)*DtvC(i+1,j)*DtvC(i,j+1)*DtvC(i+1,j+1))^0.25;
            LamAve=(LamC(i,j)*LamC(i+1,j)*LamC(i,j+1)*LamC(i+1,j+1))^0.25;
            
            H1Ave=(H1C(i,j)+H1C(i+1,j)+H1C(i,j+1)+H1C(i+1,j+1))./4;
            H2Ave=(H2C(i,j)+H2C(i+1,j)+H2C(i,j+1)+H2C(i+1,j+1))./4;
            T1Ave=(T1C(i,j)+T1C(i+1,j)+T1C(i,j+1)+T1C(i+1,j+1))./4;
            T2Ave=(T2C(i,j)+T2C(i+1,j)+T2C(i,j+1)+T2C(i+1,j+1))./4;
            
            % advection part: determine the upwind temperature 
            % liquid transfer
            aaaa=KmlAve*(HeadC(i,j+1)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i+1,j))...
                +DtlAve*(TempC(i,j+1)-TempC(i,j)+TempC(i+1,j+1)-TempC(i+1,j));
            if(aaaa>0)                                  % upwind=right
                TupWindL(1,1)=TempC(i,j+1);
                TupWindL(2,1)=TempC(i,j+1);
                TupWindL(3,1)=TempC(i+1,j+1);
                TupWindL(4,1)=TempC(i+1,j+1);
            elseif(aaaa<0)                              % upwind=left
                TupWindL(1,1)=TempC(i,j);
                TupWindL(2,1)=TempC(i,j);
                TupWindL(3,1)=TempC(i+1,j);
                TupWindL(4,1)=TempC(i+1,j);
            else                                        % no upwind
                TupWindL(1,1)=0;
                TupWindL(2,1)=0;
                TupWindL(3,1)=0;
                TupWindL(4,1)=0;
            end
            bbbb=KmlAve*(HeadC(i+1,j)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i,j+1))...
                +DtlAve*(TempC(i+1,j)-TempC(i,j)+TempC(i+1,j+1)-TempC(i,j+1));
            if(bbbb>0)                                  % upwind=up
                TupWindL(1,2)=TempC(i+1,j);
                TupWindL(2,2)=TempC(i+1,j+1);
                TupWindL(3,2)=TempC(i+1,j+1);
                TupWindL(4,2)=TempC(i+1,j);
            elseif(bbbb<0)                              % upwind=down
                TupWindL(1,2)=TempC(i,j);
                TupWindL(2,2)=TempC(i,j+1);
                TupWindL(3,2)=TempC(i,j+1);
                TupWindL(4,2)=TempC(i,j);
            else                                        % no upwind
                TupWindL(1,2)=0;
                TupWindL(2,2)=0;
                TupWindL(3,2)=0;
                TupWindL(4,2)=0;
            end
            % vapor transfer
            cccc=DmvAve*(HeadC(i,j+1)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i+1,j))...
                +DtvAve*(TempC(i,j+1)-TempC(i,j)+TempC(i+1,j+1)-TempC(i+1,j));
            if(cccc>0)                                  % upwind=right
                TupWindV(1,1)=TempC(i,j+1);
                TupWindV(2,1)=TempC(i,j+1);
                TupWindV(3,1)=TempC(i+1,j+1);
                TupWindV(4,1)=TempC(i+1,j+1);
            elseif(cccc<0)                              % upwind=left
                TupWindV(1,1)=TempC(i,j);
                TupWindV(2,1)=TempC(i,j);
                TupWindV(3,1)=TempC(i+1,j);
                TupWindV(4,1)=TempC(i+1,j);
            else                                        % no upwind
                TupWindV(1,1)=0;
                TupWindV(2,1)=0;
                TupWindV(3,1)=0;
                TupWindV(4,1)=0;
            end
            dddd=DmvAve*(HeadC(i+1,j)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i,j+1))...
                +DtvAve*(TempC(i+1,j)-TempC(i,j)+TempC(i+1,j+1)-TempC(i,j+1));
            if(dddd>0)                                  % upwind=up
                TupWindV(1,2)=TempC(i+1,j);
                TupWindV(2,2)=TempC(i+1,j+1);
                TupWindV(3,2)=TempC(i+1,j+1);
                TupWindV(4,2)=TempC(i+1,j);
            elseif(dddd<0)                              % upwind=down
                TupWindV(1,2)=TempC(i,j);
                TupWindV(2,2)=TempC(i,j+1);
                TupWindV(3,2)=TempC(i,j+1);
                TupWindV(4,2)=TempC(i,j);
            else                                        % no upwind
                TupWindV(1,2)=0;
                TupWindV(2,2)=0;
                TupWindV(3,2)=0;
                TupWindV(4,2)=0;
            end
            
            % -------------------- establish linear system --------------------
            
            % constructing the diffusive part based on MsFEM
            % Node 1
            if(MsNodeArray(i,j,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=dhf2./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                cccc=dhf2./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
%                aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
%                bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
%                cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
%                dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix: diffusion part
                
                aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                
%                 aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(1./3.*(TupWindL(1,1)-T_0)+1./3.*(TupWindL(1,2)-T_0)).*dt;  % sum(MsBaHeadGDx1.*MsTestGDx1.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy1.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                bbbb=(-1./3.*(TupWindL(2,1)-T_0)+1./6.*(TupWindL(2,2)-T_0)).*dt; % sum(MsBaHeadGDx2.*MsTestGDx1.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy1.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                cccc=(-1./6.*(TupWindL(3,1)-T_0)-1./6.*(TupWindL(3,2)-T_0)).*dt; % sum(MsBaHeadGDx3.*MsTestGDx1.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy1.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                dddd=(1./6.*(TupWindL(4,1)-T_0)-1./3.*(TupWindL(4,2)-T_0)).*dt;  % sum(MsBaHeadGDx4.*MsTestGDx1.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy1.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                
%                 aaaa2=(1./3.*(TupWindL(1,1)-T_0)+1./3.*(TupWindL(1,2)-T_0)).*dt;  % sum(MsBaTempGDx1.*MsTestGDx1.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy1.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
%                 bbbb2=(-1./3.*(TupWindL(2,1)-T_0)+1./6.*(TupWindL(2,2)-T_0)).*dt; % sum(MsBaTempGDx2.*MsTestGDx1.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy1.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
%                 cccc2=(-1./6.*(TupWindL(3,1)-T_0)-1./6.*(TupWindL(3,2)-T_0)).*dt; % sum(MsBaTempGDx3.*MsTestGDx1.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy1.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
%                 dddd2=(1./6.*(TupWindL(4,1)-T_0)-1./3.*(TupWindL(4,2)-T_0)).*dt;  % sum(MsBaTempGDx4.*MsTestGDx1.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy1.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;

                % vapor part
                
                aaaa=(1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % sum(MsBaHeadGDx1.*MsTestGDx1.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy1.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                bbbb=(-1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l; % sum(MsBaHeadGDx2.*MsTestGDx1.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy1.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                cccc=(-1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l; % sum(MsBaHeadGDx3.*MsTestGDx1.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy1.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                dddd=(1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % sum(MsBaHeadGDx4.*MsTestGDx1.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy1.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
%                 aaaa2=(1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % sum(MsBaTempGDx1.*MsTestGDx1.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy1.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 bbbb2=(-1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l; % sum(MsBaTempGDx2.*MsTestGDx1.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy1.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 cccc2=(-1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l; % sum(MsBaTempGDx3.*MsTestGDx1.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy1.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 dddd2=(1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % sum(MsBaTempGDx4.*MsTestGDx1.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy1.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
                
            elseif(MsNodeArray(i,j,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=dhf2./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                cccc=dhf2./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=TDown;
                                
                % stiffness matrix
                aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i,j,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=dhf2./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                cccc=dhf2./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;                
               
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=TUp;      
                
                % stiffness matrix
                
                aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
%                 dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
       
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 2
            if(MsNodeArray(i,j+1,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=dhf2./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                bbbb=dhf2./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                dddd=dhf2./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;

                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix: diffusion part
                
                aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part                
                
                aaaa=(-1./3.*(TupWindL(1,1)-T_0)+1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx2.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy2.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                bbbb=(1./3.*(TupWindL(2,1)-T_0)+1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx2.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy2.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                cccc=(1./6.*(TupWindL(3,1)-T_0)-1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx2.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy2.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                dddd=(-1./6.*(TupWindL(4,1)-T_0)-1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx2.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy2.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                
%                 aaaa2=(-1./3.*(TupWindL(1,1)-T_0)+1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx2.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy2.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
%                 bbbb2=(1./3.*(TupWindL(2,1)-T_0)+1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx2.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy2.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
%                 cccc2=(1./6.*(TupWindL(3,1)-T_0)-1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx2.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy2.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
%                 dddd2=(-1./6.*(TupWindL(4,1)-T_0)-1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx2.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy2.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                
                % vapor part
                                
                aaaa=(-1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx2.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy2.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                bbbb=(1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx2.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy2.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                cccc=(1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx2.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy2.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                dddd=(-1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx2.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy2.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
%                 aaaa2=(-1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx2.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy2.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 bbbb2=(1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx2.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy2.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 cccc2=(1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx2.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy2.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 dddd2=(-1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx2.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy2.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i,j+1,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=dhf2./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                bbbb=dhf2./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                dddd=dhf2./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;
              
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                             
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;
                                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=TDown;
                
                % stiffness matrix: diffusion part
                
                aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
              
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i,j+1,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=dhf2./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                bbbb=dhf2./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                dddd=dhf2./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                             
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;
                                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=TUp; 
                
                % stiffness matrix: diffusion part
                
                aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 3
            if(MsNodeArray(i+1,j+1,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=dhf2./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                cccc=dhf2./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
%                 aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix: diffusion part

                aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part                
                
                aaaa=(-1./6.*(TupWindL(1,1)-T_0)-1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx3.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy3.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                bbbb=(1./6.*(TupWindL(2,1)-T_0)-1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx3.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy3.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                cccc=(1./3.*(TupWindL(3,1)-T_0)+1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx3.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy3.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                dddd=(-1./3.*(TupWindL(4,1)-T_0)+1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx3.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy3.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                
%                 aaaa2=(-1./6.*(TupWindL(1,1)-T_0)-1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx3.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy3.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
%                 bbbb2=(1./6.*(TupWindL(2,1)-T_0)-1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx3.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy3.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
%                 cccc2=(1./3.*(TupWindL(3,1)-T_0)+1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx3.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy3.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
%                 dddd2=(-1./3.*(TupWindL(4,1)-T_0)+1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx3.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy3.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                               
                % vapor part
                
                aaaa=(-1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy3.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                bbbb=(1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy3.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                cccc=(1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy3.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                dddd=(-1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy3.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
%                 aaaa2=(-1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy3.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 bbbb2=(1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy3.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 cccc2=(1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy3.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 dddd2=(-1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy3.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i+1,j+1,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=dhf2./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                cccc=dhf2./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;
                                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=TDown;
                                               
                % stiffness matrix: diffusion part
 
                aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i+1,j+1,2)==2)  % upper boundary
                               
                % mass matrix part
                aaaa=dhf2./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                bbbb=dhf2./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                cccc=dhf2./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                dddd=dhf2./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;

                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;
                
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=TUp;
                
                % stiffness matrix: diffusion part
 
                aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 4
            if(MsNodeArray(i+1,j,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=dhf2./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                bbbb=dhf2./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                dddd=dhf2./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;
%                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix: diffusion part
 
                aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
%                 aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(1./6.*(TupWindL(1,1)-T_0)-1./3.*(TupWindL(1,2)-T_0)).*dt;    % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx4.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy4.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                bbbb=(-1./6.*(TupWindL(2,1)-T_0)-1./6.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx4.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy4.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                cccc=(-1./3.*(TupWindL(3,1)-T_0)+1./6.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx4.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy4.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                dddd=(1./3.*(TupWindL(4,1)-T_0)+1./3.*(TupWindL(4,2)-T_0)).*dt;    % dddd1=sum(MsBaHeadGDx4.*MsTestGDx4.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy4.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                
%                 aaaa2=(1./6.*(TupWindL(1,1)-T_0)-1./3.*(TupWindL(1,2)-T_0)).*dt;    % aaaa2=sum(MsBaTempGDx1.*MsTestGDx4.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy4.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
%                 bbbb2=(-1./6.*(TupWindL(2,1)-T_0)-1./6.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx4.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy4.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
%                 cccc2=(-1./3.*(TupWindL(3,1)-T_0)+1./6.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx4.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy4.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
%                 dddd2=(1./3.*(TupWindL(4,1)-T_0)+1./3.*(TupWindL(4,2)-T_0)).*dt;    % dddd2=sum(MsBaTempGDx4.*MsTestGDx4.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy4.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
%                 
                
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                                
                % vapor part
                
                aaaa=(1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;    % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx4.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy4.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                bbbb=(-1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx4.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy4.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                cccc=(-1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx4.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy4.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                dddd=(1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;    % dddd1=sum(MsBaHeadGDx4.*MsTestGDx4.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy4.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                
%                 aaaa2=(1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;    % aaaa2=sum(MsBaTempGDx1.*MsTestGDx4.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy4.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 bbbb2=(-1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx4.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy4.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 cccc2=(-1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx4.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy4.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 dddd2=(1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;    % dddd2=sum(MsBaTempGDx4.*MsTestGDx4.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy4.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
%                 
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i+1,j,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=dhf2./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                bbbb=dhf2./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                dddd=dhf2./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;

                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                               
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=0;
                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;
%                                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=TDown;
                                                
                % stiffness matrix
                aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                                
%                 aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i+1,j,2)==2)  % upper boundary
                
                % mass matrix part
                
                aaaa=dhf2./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                bbbb=dhf2./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                cccc=dhf2./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                dddd=dhf2./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;

                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                               
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=0;
                                
%                 aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
%                 bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
%                 cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
%                 dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;
%                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=TUp;
                
                % stiffness matrix: diffusion part
 
                aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                                
%                 aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;
%                 
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
        end
    end
    
    
    KK=A\B;
    
    
        
    for i=1:nh+1
        for j=1:nh+1
            HeadCtt(i,j)=min(KK(MsNodeArray(i,j,1),1),-13.0);
            TempCtt(i,j)=KK(MsNodeArray(i,j,1)+TotalNodeC,1);
        end
    end
            
    while p<5
        p=p+1;
        HeadCpp=HeadCtt;
        TempCpp=TempCtt;
        HeadCt=0.5.*(HeadCtt+HeadC);
        TempCt=0.5.*(TempCtt+TempC);
                
        for i=1:nh+1 
            for j=1:nh+1
                KmlC(i,j)=RF_Ks(i,j).*FunKml(HeadCt(i,j),TempCt(i,j));
                DtlC(i,j)=RF_Ks(i,j).*FunDtl(HeadCt(i,j),TempCt(i,j));
                DmvC(i,j)=FunDmv(HeadCt(i,j),TempCt(i,j));
                DtvC(i,j)=FunDtv(HeadCt(i,j),TempCt(i,j));
                LamC(i,j)=RF_La(i,j).*FunLambda_Bulk(HeadCt(i,j),TempCt(i,j));
                H1C(i,j)=FunH1(HeadCt(i,j),TempCt(i,j));
                H2C(i,j)=FunH2(HeadCt(i,j),TempCt(i,j));
                T1C(i,j)=FunT1(HeadCt(i,j),TempCt(i,j));
                T2C(i,j)=FunT2(HeadCt(i,j),TempCt(i,j));
            end
        end
        
        % ------------ start to assemble the finite element method ----------------
        
        EleIndex=0;
        A=sparse(2*TotalNodeC,2*TotalNodeC);
        B=sparse(2*TotalNodeC,1);
        for i=1:nh
            for j=1:nh
                

                % -------------------- preparation part --------------------

                EleIndex=EleIndex+1;
                NodeIndex1=MsEleArray(EleIndex,1);
                NodeIndex2=MsEleArray(EleIndex,2);
                NodeIndex3=MsEleArray(EleIndex,3);
                NodeIndex4=MsEleArray(EleIndex,4);

                % read the basis function and gradient matrix here


                % mean soil property across the cross element
                % Arithmetic mean?? Geometical mean?

                KmlAve=(KmlC(i,j)*KmlC(i+1,j)*KmlC(i,j+1)*KmlC(i+1,j+1))^0.25;
                DtlAve=(DtlC(i,j)*DtlC(i+1,j)*DtlC(i,j+1)*DtlC(i+1,j+1))^0.25;
                DmvAve=(DmvC(i,j)*DmvC(i+1,j)*DmvC(i,j+1)*DmvC(i+1,j+1))^0.25;
                DtvAve=(DtvC(i,j)*DtvC(i+1,j)*DtvC(i,j+1)*DtvC(i+1,j+1))^0.25;
                LamAve=(LamC(i,j)*LamC(i+1,j)*LamC(i,j+1)*LamC(i+1,j+1))^0.25;
                
                H1Ave=(H1C(i,j)+H1C(i+1,j)+H1C(i,j+1)+H1C(i+1,j+1))./4;
                H2Ave=(H2C(i,j)+H2C(i+1,j)+H2C(i,j+1)+H2C(i+1,j+1))./4;
                T1Ave=(T1C(i,j)+T1C(i+1,j)+T1C(i,j+1)+T1C(i+1,j+1))./4;
                T2Ave=(T2C(i,j)+T2C(i+1,j)+T2C(i,j+1)+T2C(i+1,j+1))./4;

                % advection part: determine the upwind temperature 
                % liquid transfer
                aaaa=KmlAve*(HeadCt(i,j+1)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i+1,j))...
                    +DtlAve*(TempCt(i,j+1)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i+1,j));
                if(aaaa>0)                                  % upwind=right
                    TupWindL(1,1)=TempCt(i,j+1);
                    TupWindL(2,1)=TempCt(i,j+1);
                    TupWindL(3,1)=TempCt(i+1,j+1);
                    TupWindL(4,1)=TempCt(i+1,j+1);
                elseif(aaaa<0)                              % upwind=left
                    TupWindL(1,1)=TempCt(i,j);
                    TupWindL(2,1)=TempCt(i,j);
                    TupWindL(3,1)=TempCt(i+1,j);
                    TupWindL(4,1)=TempCt(i+1,j);
                else                                        % no upwind
                    TupWindL(1,1)=0;
                    TupWindL(2,1)=0;
                    TupWindL(3,1)=0;
                    TupWindL(4,1)=0;
                end
                bbbb=KmlAve*(HeadCt(i+1,j)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i,j+1))...
                    +DtlAve*(TempCt(i+1,j)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i,j+1));
                if(bbbb>0)                                  % upwind=up
                    TupWindL(1,2)=TempCt(i+1,j);
                    TupWindL(2,2)=TempCt(i+1,j+1);
                    TupWindL(3,2)=TempCt(i+1,j+1);
                    TupWindL(4,2)=TempCt(i+1,j);
                elseif(bbbb<0)                              % upwind=down
                    TupWindL(1,2)=TempCt(i,j);
                    TupWindL(2,2)=TempCt(i,j+1);
                    TupWindL(3,2)=TempCt(i,j+1);
                    TupWindL(4,2)=TempCt(i,j);
                else                                        % no upwind
                    TupWindL(1,2)=0;
                    TupWindL(2,2)=0;
                    TupWindL(3,2)=0;
                    TupWindL(4,2)=0;
                end
                % vapor transfer
                cccc=DmvAve*(HeadCt(i,j+1)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i+1,j))...
                    +DtvAve*(TempCt(i,j+1)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i+1,j));
                if(cccc>0)                                  % upwind=right
                    TupWindV(1,1)=TempCt(i,j+1);
                    TupWindV(2,1)=TempCt(i,j+1);
                    TupWindV(3,1)=TempCt(i+1,j+1);
                    TupWindV(4,1)=TempCt(i+1,j+1);
                elseif(cccc<0)                              % upwind=left
                    TupWindV(1,1)=TempCt(i,j);
                    TupWindV(2,1)=TempCt(i,j);
                    TupWindV(3,1)=TempCt(i+1,j);
                    TupWindV(4,1)=TempCt(i+1,j);
                else                                        % no upwind
                    TupWindV(1,1)=0;
                    TupWindV(2,1)=0;
                    TupWindV(3,1)=0;
                    TupWindV(4,1)=0;
                end
                dddd=DmvAve*(HeadCt(i+1,j)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i,j+1))...
                    +DtvAve*(TempCt(i+1,j)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i,j+1));
                if(dddd>0)                                  % upwind=up
                    TupWindV(1,2)=TempCt(i+1,j);
                    TupWindV(2,2)=TempCt(i+1,j+1);
                    TupWindV(3,2)=TempCt(i+1,j+1);
                    TupWindV(4,2)=TempCt(i+1,j);
                elseif(dddd<0)                              % upwind=down
                    TupWindV(1,2)=TempCt(i,j);
                    TupWindV(2,2)=TempCt(i,j+1);
                    TupWindV(3,2)=TempCt(i,j+1);
                    TupWindV(4,2)=TempCt(i,j);
                else                                        % no upwind
                    TupWindV(1,2)=0;
                    TupWindV(2,2)=0;
                    TupWindV(3,2)=0;
                    TupWindV(4,2)=0;
                end

                % -------------------- establish linear system --------------------

                % constructing the diffusive part based on MsFEM
                % Node 1
                if(MsNodeArray(i,j,2)==0)  % no need to consider the boundary

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;


                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix: diffusion part

                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;


                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa1=(1./3.*(TupWindL(1,1)-T_0)+1./3.*(TupWindL(1,2)-T_0)).*dt;  % sum(MsBaHeadGDx1.*MsTestGDx1.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy1.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb1=(-1./3.*(TupWindL(2,1)-T_0)+1./6.*(TupWindL(2,2)-T_0)).*dt; % sum(MsBaHeadGDx2.*MsTestGDx1.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy1.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc1=(-1./6.*(TupWindL(3,1)-T_0)-1./6.*(TupWindL(3,2)-T_0)).*dt; % sum(MsBaHeadGDx3.*MsTestGDx1.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy1.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd1=(1./6.*(TupWindL(4,1)-T_0)-1./3.*(TupWindL(4,2)-T_0)).*dt;  % sum(MsBaHeadGDx4.*MsTestGDx1.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy1.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;

                    aaaa2=(1./3.*(TupWindL(1,1)-T_0)+1./3.*(TupWindL(1,2)-T_0)).*dt;  % sum(MsBaTempGDx1.*MsTestGDx1.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy1.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb2=(-1./3.*(TupWindL(2,1)-T_0)+1./6.*(TupWindL(2,2)-T_0)).*dt; % sum(MsBaTempGDx2.*MsTestGDx1.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy1.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc2=(-1./6.*(TupWindL(3,1)-T_0)-1./6.*(TupWindL(3,2)-T_0)).*dt; % sum(MsBaTempGDx3.*MsTestGDx1.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy1.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd2=(1./6.*(TupWindL(4,1)-T_0)-1./3.*(TupWindL(4,2)-T_0)).*dt;  % sum(MsBaTempGDx4.*MsTestGDx1.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy1.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                    
                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+KmlAve*aaaa1*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+KmlAve*bbbb1*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+KmlAve*cccc1*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+KmlAve*dddd1*rho_l*c_l;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa2*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb2*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc2*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd2*rho_l*c_l;


                    % vapor part
                    
                    aaaa1=(1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % sum(MsBaHeadGDx1.*MsTestGDx1.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy1.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb1=(-1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l; % sum(MsBaHeadGDx2.*MsTestGDx1.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy1.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc1=(-1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l; % sum(MsBaHeadGDx3.*MsTestGDx1.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy1.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd1=(1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % sum(MsBaHeadGDx4.*MsTestGDx1.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy1.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;

                    aaaa2=(1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % sum(MsBaTempGDx1.*MsTestGDx1.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy1.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb2=(-1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l; % sum(MsBaTempGDx2.*MsTestGDx1.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy1.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc2=(-1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l; % sum(MsBaTempGDx3.*MsTestGDx1.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy1.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd2=(1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % sum(MsBaTempGDx4.*MsTestGDx1.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy1.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    
                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+DmvAve*aaaa1;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+DmvAve*bbbb1;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+DmvAve*cccc1;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+DmvAve*dddd1;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa2;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb2;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc2;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd2;

                elseif(MsNodeArray(i,j,2)==1)  % bottom boundary  

                    % mass matrix part
                                        
                    aaaa=dhf.*dhf./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;
                
                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=TDown;

                    % stiffness matrix
                    
                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                
                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i,j,2)==2)  % upper boundary

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./9;                                           % sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf.*dhf;


                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./9;                                           % sum(MsBaTempMe1.*MsTestMe1,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % sum(MsBaTempMe2.*MsTestMe1,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./36;                                          % sum(MsBaTempMe3.*MsTestMe1,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % sum(MsBaTempMe4.*MsTestMe1,'all').*dhf.*dhf;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=TUp;                

                    % stiffness matrix
                    
                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=(1./3+1./3).*dt;                             % sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./3+1./6).*dt;                            % sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    cccc=(-1./6-1./6).*dt;                            % sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf.*dhf.*dt;
                    dddd=(1./6-1./3).*dt;                             % sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf.*dhf.*dt;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 2
                if(MsNodeArray(i,j+1,2)==0)  % no need to consider the boundary

                    % mass matrix part
                   
                    aaaa=dhf.*dhf./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
              
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix
                                        
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa1=(-1./3.*(TupWindL(1,1)-T_0)+1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx2.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy2.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb1=(1./3.*(TupWindL(2,1)-T_0)+1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx2.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy2.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc1=(1./6.*(TupWindL(3,1)-T_0)-1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx2.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy2.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd1=(-1./6.*(TupWindL(4,1)-T_0)-1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx2.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy2.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;

                    aaaa2=(-1./3.*(TupWindL(1,1)-T_0)+1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx2.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy2.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb2=(1./3.*(TupWindL(2,1)-T_0)+1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx2.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy2.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc2=(1./6.*(TupWindL(3,1)-T_0)-1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx2.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy2.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd2=(-1./6.*(TupWindL(4,1)-T_0)-1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx2.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy2.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;


                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+KmlAve*aaaa1*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+KmlAve*bbbb1*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+KmlAve*cccc1*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+KmlAve*dddd1*rho_l*c_l;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa2*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb2*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc2*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd2*rho_l*c_l;


                    % vapor part

                    aaaa1=(-1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx2.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy2.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb1=(1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx2.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy2.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc1=(1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx2.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy2.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd1=(-1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx2.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy2.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;

                    aaaa2=(-1./3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx2.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy2.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb2=(1./3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx2.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy2.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc2=(1./6.*(L_0+c_v.*(TupWindV(3,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx2.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy2.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd2=(-1./6.*(L_0+c_v.*(TupWindV(4,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx2.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy2.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;

                    
                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+DmvAve*aaaa1;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+DmvAve*bbbb1;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+DmvAve*cccc1;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+DmvAve*dddd1;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa2;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb2;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc2;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd2;
                

                elseif(MsNodeArray(i,j+1,2)==1)  % bottom boundary  

                    % mass matrix part                    
                    aaaa=dhf.*dhf./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=TDown;


                    % stiffness matrix
                    
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i,j+1,2)==2)  % upper boundary

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./18;                                          % sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./9;                                           % bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./36;                                          % dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf.*dhf;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=TUp; 

                    % stiffness matrix                    
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(-1./3+1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    bbbb=(1./3+1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    cccc=(1./6-1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf.*dhf.*dt;
                    dddd=(-1./6-1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf.*dhf.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 3
                if(MsNodeArray(i+1,j+1,2)==0)  % no need to consider the boundary

                    % mass matrix part
                   
                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix
                    
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
            
                    aaaa1=(-1./6.*(TupWindL(1,1)-T_0)-1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx3.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy3.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb1=(1./6.*(TupWindL(2,1)-T_0)-1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx3.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy3.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc1=(1./3.*(TupWindL(3,1)-T_0)+1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx3.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy3.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd1=(-1./3.*(TupWindL(4,1)-T_0)+1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx3.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy3.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;

                    aaaa2=(-1./6.*(TupWindL(1,1)-T_0)-1./6.*(TupWindL(1,2)-T_0)).*dt;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx3.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy3.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb2=(1./6.*(TupWindL(2,1)-T_0)-1./3.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx3.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy3.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc2=(1./3.*(TupWindL(3,1)-T_0)+1./3.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx3.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy3.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd2=(-1./3.*(TupWindL(4,1)-T_0)+1./6.*(TupWindL(4,2)-T_0)).*dt;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx3.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy3.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                    
                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+KmlAve*aaaa1*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+KmlAve*bbbb1*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+KmlAve*cccc1*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+KmlAve*dddd1*rho_l*c_l;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa2*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb2*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc2*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd2*rho_l*c_l;

                    % vapor part

                    aaaa1=(-1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy3.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb1=(1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy3.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc1=(1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy3.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd1=(-1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd1=sum(MsBaHeadGDx4.*MsTestGDx3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy3.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;

                    aaaa2=(-1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;  % aaaa2=sum(MsBaTempGDx1.*MsTestGDx3.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy3.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb2=(1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx3.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy3.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc2=(1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy3.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd2=(-1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;  % dddd2=sum(MsBaTempGDx4.*MsTestGDx3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy3.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    
                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+DmvAve*aaaa1;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+DmvAve*bbbb1;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+DmvAve*cccc1;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+DmvAve*dddd1;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa2;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb2;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc2;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd2;


                elseif(MsNodeArray(i+1,j+1,2)==1)  % bottom boundary  

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=TDown;

                    % stiffness matrix                   
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
           
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i+1,j+1,2)==2)  % upper boundary

                    % mass matrix part                    
                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./36;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./18;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./9;                                           % cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./18;                                          % dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf.*dhf;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=TUp;


                    % stiffness matrix
                    
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(-1./6-1./6).*dt;                             % aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    bbbb=(1./6-1./3).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    cccc=(1./3+1./3).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf.*dhf.*dt;
                    dddd=(-1./3+1./6).*dt;                             % dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf.*dhf.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 4
                if(MsNodeArray(i+1,j,2)==0)  % no need to consider the boundary

                    % mass matrix part                   
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;
                
                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));


                    % stiffness matrix
                    
                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                    
                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                   
                    aaaa1=(1./6.*(TupWindL(1,1)-T_0)-1./3.*(TupWindL(1,2)-T_0)).*dt;    % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx4.*(TupWindL(1,1)-T_0)+MsBaHeadGDy1.*MsTestGDy4.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb1=(-1./6.*(TupWindL(2,1)-T_0)-1./6.*(TupWindL(2,2)-T_0)).*dt;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx4.*(TupWindL(2,1)-T_0)+MsBaHeadGDy2.*MsTestGDy4.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc1=(-1./3.*(TupWindL(3,1)-T_0)+1./6.*(TupWindL(3,2)-T_0)).*dt;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx4.*(TupWindL(3,1)-T_0)+MsBaHeadGDy3.*MsTestGDy4.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd1=(1./3.*(TupWindL(4,1)-T_0)+1./3.*(TupWindL(4,2)-T_0)).*dt;    % dddd1=sum(MsBaHeadGDx4.*MsTestGDx4.*(TupWindL(4,1)-T_0)+MsBaHeadGDy4.*MsTestGDy4.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;

                    aaaa2=(1./6.*(TupWindL(1,1)-T_0)-1./3.*(TupWindL(1,2)-T_0)).*dt;    % aaaa2=sum(MsBaTempGDx1.*MsTestGDx4.*(TupWindL(1,1)-T_0)+MsBaTempGDy1.*MsTestGDy4.*(TupWindL(1,2)-T_0),'all').*dhf.*dhf.*dt;
                    bbbb2=(-1./6.*(TupWindL(2,1)-T_0)-1./6.*(TupWindL(2,2)-T_0)).*dt;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx4.*(TupWindL(2,1)-T_0)+MsBaTempGDy2.*MsTestGDy4.*(TupWindL(2,2)-T_0),'all').*dhf.*dhf.*dt;
                    cccc2=(-1./3.*(TupWindL(3,1)-T_0)+1./6.*(TupWindL(3,2)-T_0)).*dt;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx4.*(TupWindL(3,1)-T_0)+MsBaTempGDy3.*MsTestGDy4.*(TupWindL(3,2)-T_0),'all').*dhf.*dhf.*dt;
                    dddd2=(1./3.*(TupWindL(4,1)-T_0)+1./3.*(TupWindL(4,2)-T_0)).*dt;    % dddd2=sum(MsBaTempGDx4.*MsTestGDx4.*(TupWindL(4,1)-T_0)+MsBaTempGDy4.*MsTestGDy4.*(TupWindL(4,2)-T_0),'all').*dhf.*dhf.*dt;
                    
                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+KmlAve*aaaa1*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+KmlAve*bbbb1*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+KmlAve*cccc1*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+KmlAve*dddd1*rho_l*c_l;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa2*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb2*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc2*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd2*rho_l*c_l;

                    % vapor part
                    
                    aaaa1=(1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;    % aaaa1=sum(MsBaHeadGDx1.*MsTestGDx4.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaHeadGDy1.*MsTestGDy4.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb1=(-1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb1=sum(MsBaHeadGDx2.*MsTestGDx4.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaHeadGDy2.*MsTestGDy4.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc1=(-1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc1=sum(MsBaHeadGDx3.*MsTestGDx4.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaHeadGDy3.*MsTestGDy4.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd1=(1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;    % dddd1=sum(MsBaHeadGDx4.*MsTestGDx4.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaHeadGDy4.*MsTestGDy4.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;

                    aaaa2=(1./6.*(L_0+c_v.*(TupWindV(1,1)-T_0))-1./3.*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dt.*rho_l;    % aaaa2=sum(MsBaTempGDx1.*MsTestGDx4.*(L_0+c_v.*(TupWindV(1,1)-T_0))+MsBaTempGDy1.*MsTestGDy4.*(L_0+c_v.*(TupWindV(1,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    bbbb2=(-1./6.*(L_0+c_v.*(TupWindV(2,1)-T_0))-1./6.*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dt.*rho_l;   % bbbb2=sum(MsBaTempGDx2.*MsTestGDx4.*(L_0+c_v.*(TupWindV(2,1)-T_0))+MsBaTempGDy2.*MsTestGDy4.*(L_0+c_v.*(TupWindV(2,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    cccc2=(-1./3.*(L_0+c_v.*(TupWindV(3,1)-T_0))+1./6.*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dt.*rho_l;   % cccc2=sum(MsBaTempGDx3.*MsTestGDx4.*(L_0+c_v.*(TupWindV(3,1)-T_0))+MsBaTempGDy3.*MsTestGDy4.*(L_0+c_v.*(TupWindV(3,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    dddd2=(1./3.*(L_0+c_v.*(TupWindV(4,1)-T_0))+1./3.*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dt.*rho_l;    % dddd2=sum(MsBaTempGDx4.*MsTestGDx4.*(L_0+c_v.*(TupWindV(4,1)-T_0))+MsBaTempGDy4.*MsTestGDy4.*(L_0+c_v.*(TupWindV(4,2)-T_0)),'all').*dhf.*dhf.*dt.*rho_l;
                    
                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+DmvAve*aaaa1;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+DmvAve*bbbb1;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+DmvAve*cccc1;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+DmvAve*dddd1;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa2;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb2;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc2;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd2;


                elseif(MsNodeArray(i+1,j,2)==1)  % bottom boundary  

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=0;
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;
 
                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=TDown;


                    % stiffness matrix
                    
                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i+1,j,2)==2)  % upper boundary

                    % mass matrix part
                    
                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf.*dhf;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=0;

                    aaaa=dhf.*dhf./18;                                          % aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf.*dhf;
                    bbbb=dhf.*dhf./36;                                          % bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf.*dhf;
                    cccc=dhf.*dhf./18;                                          % cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf.*dhf;
                    dddd=dhf.*dhf./9;                                           % dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf.*dhf;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=TUp;

                    % stiffness matrix
                    
                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
          
                    aaaa=(1./6-1./3).*dt;                               % aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    bbbb=(-1./6-1./6).*dt;                              % bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    cccc=(-1./3+1./6).*dt;                              % cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf.*dhf.*dt;
                    dddd=(1./3+1./3).*dt;                               % dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf.*dhf.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

            end
        end
        
        KK=A\B;
    
        for i=1:nh+1
            for j=1:nh+1
                HeadCtt(i,j)=min(KK(MsNodeArray(i,j,1),1),-13.0);
                TempCtt(i,j)=KK(MsNodeArray(i,j,1)+TotalNodeC,1);
            end
        end
        
        max1=max(abs(HeadCtt-HeadCpp)./max(abs(HeadCpp),[],'all'),[],'all');
        max2=max(abs(TempCtt-TempCpp)./max(abs(TempCpp),[],'all'),[],'all');
       
        if (max(max1,max2)<epsilon)
            p=6;
            HeadC=HeadCtt;
            TempC=TempCtt;
            TotalT=TotalT+dt;
            dt=min(dt_max,dt*1.5);
            if(SaveThreshold-TotalT>0)
                dt=min(dt,SaveThreshold-TotalT);
            end
        end
        
        if p==5
            dt=dt/2;
        end 
       
    end
    
    for i=1:nh+1
        for j=1:nh+1
            ThetaC(i,j)=FunWrc(HeadC(i,j),TempC(i,j),1);
        end
    end
    
    wzjwzjt=toc
      
    
    if TotalT>=SaveThreshold
        ThetaSave(:,TSindex)=reshape(ThetaC,[],1);
        HeadSave(:,TSindex)=reshape(HeadC,[],1);
        TmprSave(:,TSindex)=reshape(TempC,[],1);
        ElaspSave(TSindex,1)=wzjwzjt;
        SaveThreshold=SaveThreshold+3600;
        TSindex=TSindex+1;
    end
 
end

xlswrite('fine020.xlsx',ThetaSave,'theta');
xlswrite('fine020.xlsx',HeadSave,'head');
xlswrite('fine020.xlsx',TmprSave,'temp');
xlswrite('fine020.xlsx',ElaspSave,'ElaspTime');


