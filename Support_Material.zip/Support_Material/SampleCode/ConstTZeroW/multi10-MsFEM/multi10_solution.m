% USDA example 1
% constant temperature (may need to low the water content)

clear all
close all
clc

H=100; % unit cm
T=10*24*3600; % the input is "day", but the 
nh=10; % number of spatial nodes
dt_0=1; % unit of second
dt_max=1800;

dh=H/nh;
dt=dt_0;
TotalT=0;
TotalNodeC=(nh+1)*(nh+1);
epsilon=0.01;
theta_ini=0.2;
tmpr_ini=25;
head_ini=FunWrc(theta_ini,tmpr_ini,2);

% prelim parameters
rho_l=1.000;    % "g cm^-3"
L_0=2270;       % "J g^-1"
c_v=1.864;      % "J g^-1 K-1"
c_l=4.187;      % "J g^-1 K-1"
T_0=25;          % "oC"
theta_s=0.547;
var_xi=0.01;
TupWindL=zeros(4,2);
TupWindV=zeros(4,2);

% assume boundary conditions
TUp=30;
TDown=20;

% ----------------- here we need to load the random field ---------------
%RF_Ks=ones(nh+1);
%RF_La=ones(nh+1);
load RF_Ks.mat
load RF_La.mat
multiscale=10;
nhT=nh*multiscale;
TotalNodeL=(multiscale+1)*(multiscale+1);
% 
% MsRatio=100/nh/multiscale;
%  
% for i=1:nhT+1
%     for j=1:nhT+1
%         RF_Ks1(i,j)=RF_Ks((i-1)*MsRatio+1,(j-1)*MsRatio+1);
%         RF_La1(i,j)=RF_La((i-1)*MsRatio+1,(j-1)*MsRatio+1);
%     end
% end
% 
% RF_Ks=RF_Ks1;
% RF_La=RF_La1;

% ----------------- multiscale initialization ---------------------------

dhf=dh/multiscale;
dhf2=dhf.*dhf;

HeadC=zeros(nh+1,nh+1); % from bottom to top (Crse)
TempC=zeros(nh+1,nh+1);
ThetaC=zeros(nh+1,nh+1);

for i=1:nh+1
    for j=1:nh+1
        HeadC(i,j)=head_ini;
        TempC(i,j)=tmpr_ini;
        ThetaC(i,j)=theta_ini;
    end
end
for j=1:nh+1
    TempC(1,j)=TDown;
    TempC(nh+1,j)=TUp;
end

Head=zeros(nhT+1,nhT+1); % from bottom to top (fine)
Temp=zeros(nhT+1,nhT+1);
Theta=zeros(nhT+1,nhT+1);

for i=1:nhT+1
    for j=1:nhT+1
        Head(i,j)=head_ini;
        Temp(i,j)=tmpr_ini;
        Theta(i,j)=theta_ini;
    end
end
for j=1:nhT+1
    Temp(1,j)=TDown;
    Temp(nhT+1,j)=TUp;
end

% ------------------ the multiscale basis --------------------------------

MsBasisArray=cell(nh*nh,8);
MsBasisArrayMe=cell(nh*nh,8);
MsBasisArrayGDx=cell(nh*nh,8);
MsBasisArrayGDy=cell(nh*nh,8);
MsEleArray=ones(nh*nh,4);
MsNodeArray=zeros((nh+1),(nh+1),2);
for i=1:nh+1 
    for j=1:nh+1
        MsNodeArray(i,j,1)=(i-1)*(nh+1)+j;
        MsNodeArray(i,j,2)=0+1*(i==1)+2*(i==nh+1);
    end
end 
EleIndex=0;
for i=1:nh 
    for j=1:nh
        EleIndex=EleIndex+1;
        MsEleArray(EleIndex,1)=MsNodeArray(i,j,1);
        MsEleArray(EleIndex,2)=MsNodeArray(i,j+1,1);
        MsEleArray(EleIndex,3)=MsNodeArray(i+1,j+1,1);
        MsEleArray(EleIndex,4)=MsNodeArray(i+1,j,1);
    end
end 

MsBaHead1=ones(multiscale+1,multiscale+1);
MsBaHead2=ones(multiscale+1,multiscale+1);
MsBaHead3=ones(multiscale+1,multiscale+1);
MsBaHead4=ones(multiscale+1,multiscale+1);
MsBaTemp1=ones(multiscale+1,multiscale+1);
MsBaTemp2=ones(multiscale+1,multiscale+1);
MsBaTemp3=ones(multiscale+1,multiscale+1);
MsBaTemp4=ones(multiscale+1,multiscale+1);

MsBaHeadMe1=ones(multiscale,multiscale);
MsBaHeadMe2=ones(multiscale,multiscale);
MsBaHeadMe3=ones(multiscale,multiscale);
MsBaHeadMe4=ones(multiscale,multiscale);
MsBaTempMe1=ones(multiscale,multiscale);
MsBaTempMe2=ones(multiscale,multiscale);
MsBaTempMe3=ones(multiscale,multiscale);
MsBaTempMe4=ones(multiscale,multiscale);

MsBaHeadGDx1=ones(multiscale,multiscale);
MsBaHeadGDx2=ones(multiscale,multiscale);
MsBaHeadGDx3=ones(multiscale,multiscale);
MsBaHeadGDx4=ones(multiscale,multiscale);
MsBaTempGDx1=ones(multiscale,multiscale);
MsBaTempGDx2=ones(multiscale,multiscale);
MsBaTempGDx3=ones(multiscale,multiscale);
MsBaTempGDx4=ones(multiscale,multiscale);

MsBaHeadGDy1=ones(multiscale,multiscale);
MsBaHeadGDy2=ones(multiscale,multiscale);
MsBaHeadGDy3=ones(multiscale,multiscale);
MsBaHeadGDy4=ones(multiscale,multiscale);
MsBaTempGDy1=ones(multiscale,multiscale);
MsBaTempGDy2=ones(multiscale,multiscale);
MsBaTempGDy3=ones(multiscale,multiscale);
MsBaTempGDy4=ones(multiscale,multiscale);

MsTest1=ones(multiscale+1,multiscale+1);
MsTest2=ones(multiscale+1,multiscale+1);
MsTest3=ones(multiscale+1,multiscale+1);
MsTest4=ones(multiscale+1,multiscale+1);

MsTestMe1=ones(multiscale,multiscale);
MsTestMe2=ones(multiscale,multiscale);
MsTestMe3=ones(multiscale,multiscale);
MsTestMe4=ones(multiscale,multiscale);

MsTestGDx1=ones(multiscale,multiscale);
MsTestGDx2=ones(multiscale,multiscale);
MsTestGDx3=ones(multiscale,multiscale);
MsTestGDx4=ones(multiscale,multiscale);

MsTestGDy1=ones(multiscale,multiscale);
MsTestGDy2=ones(multiscale,multiscale);
MsTestGDy3=ones(multiscale,multiscale);
MsTestGDy4=ones(multiscale,multiscale);

for i=1:multiscale+1 
    for j=1:multiscale+1
        MsTest1(i,j)=(multiscale+1-i)*(multiscale+1-j);
        MsTest2(i,j)=(multiscale+1-i)*(j-1);
        MsTest3(i,j)=(i-1)*(j-1);
        MsTest4(i,j)=(i-1)*(multiscale+1-j);
    end
end 
MsTest1=MsTest1./(multiscale.*multiscale);
MsTest2=MsTest2./(multiscale.*multiscale);
MsTest3=MsTest3./(multiscale.*multiscale);
MsTest4=MsTest4./(multiscale.*multiscale);

% give the gradient here
for i=1:multiscale
    for j=1:multiscale
        MsTestGDx1(i,j)=(MsTest1(i,j+1)-MsTest1(i,j)+MsTest1(i+1,j+1)-MsTest1(i+1,j))/2/dhf;
        MsTestGDx2(i,j)=(MsTest2(i,j+1)-MsTest2(i,j)+MsTest2(i+1,j+1)-MsTest2(i+1,j))/2/dhf;
        MsTestGDx3(i,j)=(MsTest3(i,j+1)-MsTest3(i,j)+MsTest3(i+1,j+1)-MsTest3(i+1,j))/2/dhf;
        MsTestGDx4(i,j)=(MsTest4(i,j+1)-MsTest4(i,j)+MsTest4(i+1,j+1)-MsTest4(i+1,j))/2/dhf;
        
        MsTestGDy1(i,j)=(MsTest1(i+1,j)-MsTest1(i,j)+MsTest1(i+1,j+1)-MsTest1(i,j+1))/2/dhf;
        MsTestGDy2(i,j)=(MsTest2(i+1,j)-MsTest2(i,j)+MsTest2(i+1,j+1)-MsTest2(i,j+1))/2/dhf;
        MsTestGDy3(i,j)=(MsTest3(i+1,j)-MsTest3(i,j)+MsTest3(i+1,j+1)-MsTest3(i,j+1))/2/dhf;
        MsTestGDy4(i,j)=(MsTest4(i+1,j)-MsTest4(i,j)+MsTest4(i+1,j+1)-MsTest4(i,j+1))/2/dhf;
        
        MsTestMe1(i,j)=(MsTest1(i+1,j)+MsTest1(i,j)+MsTest1(i+1,j+1)+MsTest1(i,j+1))/4;
        MsTestMe2(i,j)=(MsTest2(i+1,j)+MsTest2(i,j)+MsTest2(i+1,j+1)+MsTest2(i,j+1))/4;
        MsTestMe3(i,j)=(MsTest3(i+1,j)+MsTest3(i,j)+MsTest3(i+1,j+1)+MsTest3(i,j+1))/4;
        MsTestMe4(i,j)=(MsTest4(i+1,j)+MsTest4(i,j)+MsTest4(i+1,j+1)+MsTest4(i,j+1))/4;
    end
end 

% ------------------ reserve some parameter matrix -----------------------

% global/fine matrix
KmlG=zeros(nhT+1,nhT+1);
DtlG=zeros(nhT+1,nhT+1);
DmvG=zeros(nhT+1,nhT+1);
DtvG=zeros(nhT+1,nhT+1);
LamG=zeros(nhT+1,nhT+1);

% coarse matrix
KmlC=zeros(nh+1,nh+1);
DtlC=zeros(nh+1,nh+1);
DmvC=zeros(nh+1,nh+1);
DtvC=zeros(nh+1,nh+1);
LamC=zeros(nh+1,nh+1);
H1C=zeros(nh+1,nh+1);
H2C=zeros(nh+1,nh+1);
T1C=zeros(nh+1,nh+1);
T2C=zeros(nh+1,nh+1);

% local matrix
KmlL=zeros(multiscale+1,multiscale+1);
DtlL=zeros(multiscale+1,multiscale+1);
DmvL=zeros(multiscale+1,multiscale+1);
DtvL=zeros(multiscale+1,multiscale+1);
LamL=zeros(multiscale+1,multiscale+1);

% ------------------ temp vars for iterations -----------------------
HeadCt=HeadC;
TempCt=TempC;
HeadCtt=HeadC;
TempCtt=TempC;
HeadCpp=HeadC;
TempCpp=TempC;

Headt=Head;
Tempt=Temp;
Headtt=Head;
Temptt=Temp;
Headpp=Head;
Temppp=Temp;

% install the intial condition
SaveThreshold=0;
TSindex=1;
ThetaSave=zeros((nhT+1)*(nhT+1),241);
HeadSave=zeros((nhT+1)*(nhT+1),241);
TmprSave=zeros((nhT+1)*(nhT+1),241);
ElaspSave=zeros(241,1);

% update basis control
UpdateMsBasis=0;

% begin the time domain iteration, Total time is the stop citerion
while TotalT<T
    
    tic
    
    for i=1:nhT+1 
        for j=1:nhT+1
            KmlG(i,j)=RF_Ks(i,j).*FunKml(Head(i,j),Temp(i,j));
            DtlG(i,j)=RF_Ks(i,j).*FunDtl(Head(i,j),Temp(i,j));
            DmvG(i,j)=FunDmv(Head(i,j),Temp(i,j));
            DtvG(i,j)=FunDtv(Head(i,j),Temp(i,j));
            LamG(i,j)=RF_La(i,j).*FunLambda_Bulk(Head(i,j),Temp(i,j));
        end
    end
    for i=1:nh+1 
        for j=1:nh+1
            KmlC(i,j)=KmlG((i-1)*multiscale+1,(j-1)*multiscale+1);
            DtlC(i,j)=DtlG((i-1)*multiscale+1,(j-1)*multiscale+1);
            DmvC(i,j)=DmvG((i-1)*multiscale+1,(j-1)*multiscale+1);
            DtvC(i,j)=DtvG((i-1)*multiscale+1,(j-1)*multiscale+1);
            LamC(i,j)=LamG((i-1)*multiscale+1,(j-1)*multiscale+1);
            H1C(i,j)=FunH1(HeadC(i,j),TempC(i,j));
            H2C(i,j)=FunH2(HeadC(i,j),TempC(i,j));
            T1C(i,j)=FunT1(HeadC(i,j),TempC(i,j));
            T2C(i,j)=FunT2(HeadC(i,j),TempC(i,j));
        end
    end
      
% ----------- establish multiscale finite element basis -------------------

    if(UpdateMsBasis==0)
        UpdateMsBasis=0;
        
    for i=1:nh 
        for j=1:nh
            
            KmlL=KmlG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            DtlL=DtlG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            LamL=LamG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            
            MsBaHead1=zeros(multiscale+1,multiscale+1);
            MsBaHead2=zeros(multiscale+1,multiscale+1);
            MsBaHead3=zeros(multiscale+1,multiscale+1);
            MsBaHead4=zeros(multiscale+1,multiscale+1);
            MsBaTemp1=zeros(multiscale+1,multiscale+1);
            MsBaTemp2=zeros(multiscale+1,multiscale+1);
            MsBaTemp3=zeros(multiscale+1,multiscale+1);
            MsBaTemp4=zeros(multiscale+1,multiscale+1);
            
            MsBaHead1(1,1)=1;MsBaTemp1(1,1)=1;
            MsBaHead2(1,multiscale+1)=1;MsBaTemp2(1,multiscale+1)=1;
            MsBaHead3(multiscale+1,multiscale+1)=1;MsBaTemp3(multiscale+1,multiscale+1)=1;
            MsBaHead4(multiscale+1,1)=1; MsBaTemp4(multiscale+1,1)=1;
            
            % first do the temperature basis function

            % numerically solve the boundary condition
            % boundary I
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(LamL(1,jj)*LamL(1,jj-1));
                A(jj,jj+1)=sqrt(LamL(1,jj)*LamL(1,jj+1));
                A(jj,jj)=-sqrt(LamL(1,jj)*LamL(1,jj-1))...
                    -sqrt(LamL(1,jj)*LamL(1,jj+1));
                B(jj,1)=0;
            end
            KKI=A\B;
            for jj=1:multiscale+1
                MsBaTemp1(1,jj)=KKI(jj);
                MsBaTemp2(1,jj)=1-MsBaTemp1(1,jj);
            end
            
            % boundary II
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(LamL(ii,multiscale+1)*LamL(ii-1,multiscale+1));
                A(ii,ii+1)=sqrt(LamL(ii,multiscale+1)*LamL(ii+1,multiscale+1));
                A(ii,ii)=-sqrt(LamL(ii,multiscale+1)*LamL(ii-1,multiscale+1))...
                    -sqrt(LamL(ii,multiscale+1)*LamL(ii+1,multiscale+1));
                B(ii,1)=0;
            end
            KKII=A\B;
            for ii=1:multiscale+1
                MsBaTemp2(ii,multiscale+1)=KKII(ii);
                MsBaTemp3(ii,multiscale+1)=1-MsBaTemp2(ii,multiscale+1);
            end
            
            % boundary III
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj-1));
                A(jj,jj+1)=sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj+1));
                A(jj,jj)=-sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj-1))...
                    -sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj+1));
                B(jj,1)=0;
            end
            KKIII=A\B;
            for jj=1:multiscale+1
                MsBaTemp4(multiscale+1,jj)=KKIII(jj);
                MsBaTemp3(multiscale+1,jj)=1-MsBaTemp4(multiscale+1,jj);
            end
            
            % boundary IV
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(LamL(ii,1)*LamL(ii-1,1));
                A(ii,ii+1)=sqrt(LamL(ii,1)*LamL(ii+1,1));
                A(ii,ii)=-sqrt(LamL(ii,1)*LamL(ii-1,1))...
                    -sqrt(LamL(ii,1)*LamL(ii+1,1));
                B(ii,1)=0;
            end
            KKIV=A\B;
            for ii=1:multiscale+1
                MsBaTemp1(ii,1)=KKIV(ii);
                MsBaTemp4(ii,1)=1-MsBaTemp1(ii,1);
            end
            
            clear A B KKI KKII KKIII KKIV;
                        
            A=sparse(TotalNodeL,TotalNodeL);
            B1=sparse(TotalNodeL,1);
            B2=sparse(TotalNodeL,1);
            B3=sparse(TotalNodeL,1);
            B4=sparse(TotalNodeL,1);
            for ii=1:multiscale
                for jj=1:multiscale
                    Node1=(ii-1)*(multiscale+1)+jj;
                    Node2=(ii-1)*(multiscale+1)+jj+1;
                    Node3=ii*(multiscale+1)+jj+1;
                    Node4=ii*(multiscale+1)+jj;
%                    LamLAve=(LamL(ii,jj)+LamL(ii,jj+1)+LamL(ii+1,jj+1)+LamL(ii+1,jj))./4;
                    
                    LamLAve=(LamL(ii,jj)*LamL(ii,jj+1)*LamL(ii+1,jj+1)*LamL(ii+1,jj))^0.25;
                    
                    % Basis 1
                    if(ii==1||jj==1)
                        A(Node1,Node1)=1;
                        B1(Node1,1)=MsBaTemp1(ii,jj);
                        B2(Node1,1)=MsBaTemp2(ii,jj);
                        B3(Node1,1)=MsBaTemp3(ii,jj);
                        B4(Node1,1)=MsBaTemp4(ii,jj);
                    else
                        A(Node1,Node1)=A(Node1,Node1)+(1/3+1/3)*LamLAve;
                        A(Node1,Node2)=A(Node1,Node2)+(-1/3+1/6)*LamLAve;
                        A(Node1,Node3)=A(Node1,Node3)+(-1/6-1/6)*LamLAve;
                        A(Node1,Node4)=A(Node1,Node4)+(1/6-1/3)*LamLAve;
                        B1(Node1,1)=0;
                        B2(Node1,1)=0;
                        B3(Node1,1)=0;
                        B4(Node1,1)=0;
                    end
                    
                    % Basis 2
                    if(ii==1||jj==multiscale)
                        A(Node2,Node2)=1;
                        B1(Node2,1)=MsBaTemp1(ii,jj+1);
                        B2(Node2,1)=MsBaTemp2(ii,jj+1);
                        B3(Node2,1)=MsBaTemp3(ii,jj+1);
                        B4(Node2,1)=MsBaTemp4(ii,jj+1);
                    else
                        A(Node2,Node1)=A(Node2,Node1)+(-1/3+1/6)*LamLAve;
                        A(Node2,Node2)=A(Node2,Node2)+(1/3+1/3)*LamLAve;
                        A(Node2,Node3)=A(Node2,Node3)+(1/6-1/3)*LamLAve;
                        A(Node2,Node4)=A(Node2,Node4)+(-1/6-1/6)*LamLAve;
                        B1(Node2,1)=0;
                        B2(Node2,1)=0;
                        B3(Node2,1)=0;
                        B4(Node2,1)=0;
                    end
                    
                    % Basis 3
                    if(ii==multiscale||jj==multiscale)
                        A(Node3,Node3)=1;
                        B1(Node3,1)=MsBaTemp1(ii+1,jj+1);
                        B2(Node3,1)=MsBaTemp2(ii+1,jj+1);
                        B3(Node3,1)=MsBaTemp3(ii+1,jj+1);
                        B4(Node3,1)=MsBaTemp4(ii+1,jj+1);
                    else
                        A(Node3,Node1)=A(Node3,Node1)+(-1/6-1/6)*LamLAve;
                        A(Node3,Node2)=A(Node3,Node2)+(1/6-1/3)*LamLAve;
                        A(Node3,Node3)=A(Node3,Node3)+(1/3+1/3)*LamLAve;
                        A(Node3,Node4)=A(Node3,Node4)+(-1/3+1/6)*LamLAve;
                        B1(Node3,1)=0;
                        B2(Node3,1)=0;
                        B3(Node3,1)=0;
                        B4(Node3,1)=0;
                    end
                    
                    % Basis 4
                    if(ii==multiscale||jj==1)
                        A(Node4,Node4)=1;
                        B1(Node4,1)=MsBaTemp1(ii+1,jj);
                        B2(Node4,1)=MsBaTemp2(ii+1,jj);
                        B3(Node4,1)=MsBaTemp3(ii+1,jj);
                        B4(Node4,1)=MsBaTemp4(ii+1,jj);
                    else
                        A(Node4,Node1)=A(Node4,Node1)+(1/6-1/3)*LamLAve;
                        A(Node4,Node2)=A(Node4,Node2)+(-1/6-1/6)*LamLAve;
                        A(Node4,Node3)=A(Node4,Node3)+(-1/3+1/6)*LamLAve;
                        A(Node4,Node4)=A(Node4,Node4)+(1/3+1/3)*LamLAve;
                        B1(Node4,1)=0;
                        B2(Node4,1)=0;
                        B3(Node4,1)=0;
                        B4(Node4,1)=0;
                    end
                end
            end
            KK1=A\B1;
            KK2=A\B2;
            KK3=A\B3;
            KK4=A\B4;
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaTemp1(ii,jj)=KK1((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp2(ii,jj)=KK2((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp3(ii,jj)=KK3((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp4(ii,jj)=KK4((ii-1)*(multiscale+1)+jj,1);
                end
            end
            
            clear A B1 B2 B3 B4 KK1 KK2 KK3 KK4;
            
            % make sure the 0 boundary is exactly 0 (in case)
            MsBaTemp1(multiscale+1,1)=0;    MsBaTemp1(1,multiscale+1)=0;
            MsBaTemp2(1,1)=0;               MsBaTemp2(multiscale+1,multiscale+1)=0;
            MsBaTemp3(1,multiscale+1)=0;    MsBaTemp3(multiscale+1,1)=0;
            MsBaTemp4(1,1)=0;               MsBaTemp4(multiscale+1,multiscale+1)=0;
            
            % second do the water content basis function
            % why two basis should be aligned? i.e.,
            % MsBaHeadx \sim MsBaTempx, if think head and temp as a long
            % vector and each spatial location correspond two 1 of water
            % and temp associated. 

            % numerically solve the boundary condition
            % boundary I
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(KmlL(1,jj)*KmlL(1,jj-1));
                A(jj,jj+1)=sqrt(KmlL(1,jj)*KmlL(1,jj+1));
                A(jj,jj)=-sqrt(KmlL(1,jj)*KmlL(1,jj-1))...
                    -sqrt(KmlL(1,jj)*KmlL(1,jj+1));
                B(jj,1)=(sqrt(DtlL(1,jj)*DtlL(1,jj-1))*(MsBaTemp1(1,jj)-MsBaTemp1(1,jj-1))...
                    +sqrt(DtlL(1,jj)*DtlL(1,jj+1))*(MsBaTemp1(1,jj)-MsBaTemp1(1,jj+1)))...
                    *var_xi;
            end
            KKI=A\B;
            for jj=1:multiscale+1
                MsBaHead1(1,jj)=min(max(KKI(jj),0),1);
                MsBaHead2(1,jj)=1-MsBaHead1(1,jj);
            end
            
            % boundary II
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(KmlL(ii,multiscale+1)*KmlL(ii-1,multiscale+1));
                A(ii,ii+1)=sqrt(KmlL(ii,multiscale+1)*KmlL(ii+1,multiscale+1));
                A(ii,ii)=-sqrt(KmlL(ii,multiscale+1)*KmlL(ii-1,multiscale+1))...
                    -sqrt(KmlL(ii,multiscale+1)*KmlL(ii+1,multiscale+1));
                B(ii,1)=(sqrt(DtlL(ii,multiscale+1)*DtlL(ii-1,multiscale+1))...
                    *(MsBaTemp2(ii,multiscale+1)-MsBaTemp2(ii-1,multiscale-1))...
                    +sqrt(DtlL(ii,multiscale+1)*DtlL(ii+1,multiscale+1))...
                    *(MsBaTemp2(ii,multiscale+1)-MsBaTemp2(ii+1,multiscale-1)))...
                    *var_xi;
            end
            KKII=A\B;
            for ii=1:multiscale+1
                MsBaHead2(ii,multiscale+1)=min(max(KKII(ii),0),1);
                MsBaHead3(ii,multiscale+1)=1-MsBaHead2(ii,multiscale+1);
            end
            
            % boundary III
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj-1));
                A(jj,jj+1)=sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj+1));
                A(jj,jj)=-sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj-1))...
                    -sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj+1));
                B(jj,1)=(sqrt(DtlL(multiscale+1,jj)*DtlL(multiscale+1,jj-1))...
                    *(MsBaTemp4(multiscale+1,jj)-MsBaTemp4(multiscale+1,jj-1))...
                    +sqrt(DtlL(multiscale+1,jj)*DtlL(multiscale+1,jj+1))...
                    *(MsBaTemp4(multiscale+1,jj)-MsBaTemp4(multiscale+1,jj+1)))...
                    *var_xi;
            end
            KKIII=A\B;
            for jj=1:multiscale+1
                MsBaHead4(multiscale+1,jj)=min(max(KKIII(jj),0),1);
                MsBaHead3(multiscale+1,jj)=1-MsBaHead4(multiscale+1,jj);
            end
            
            % boundary IV
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(KmlL(ii,1)*KmlL(ii-1,1));
                A(ii,ii+1)=sqrt(KmlL(ii,1)*KmlL(ii+1,1));
                A(ii,ii)=-sqrt(KmlL(ii,1)*KmlL(ii-1,1))...
                    -sqrt(KmlL(ii,1)*KmlL(ii+1,1));
                B(ii,1)=(sqrt(KmlL(ii,1)*KmlL(ii-1,1))...
                    *(MsBaTemp1(ii,1)-MsBaTemp1(ii-1,1))...
                    +sqrt(KmlL(ii,1)*KmlL(ii+1,1))...
                    *(MsBaTemp1(ii,1)-MsBaTemp1(ii+1,1)))...
                    *var_xi;
            end
            KKIV=A\B;
            for ii=1:multiscale+1
                MsBaHead1(ii,1)=min(max(KKIV(ii),0),1);
                MsBaHead4(ii,1)=1-MsBaHead1(ii,1);
            end
            
            clear A B KKI KKII KKIII KKIV;
                        
            A=sparse(TotalNodeL,TotalNodeL);
            B1=sparse(TotalNodeL,1);
            B2=sparse(TotalNodeL,1);
            B3=sparse(TotalNodeL,1);
            B4=sparse(TotalNodeL,1);
            for ii=1:multiscale
                for jj=1:multiscale
                    Node1=(ii-1)*(multiscale+1)+jj;
                    Node2=(ii-1)*(multiscale+1)+jj+1;
                    Node3=ii*(multiscale+1)+jj+1;
                    Node4=ii*(multiscale+1)+jj;
                    
%                     KmlLAve=(KmlL(ii,jj)+KmlL(ii,jj+1)+KmlL(ii+1,jj+1)+KmlL(ii+1,jj))./4;
%                     DtlLAve=(DtlL(ii,jj)+DtlL(ii,jj+1)+DtlL(ii+1,jj+1)+DtlL(ii+1,jj))./4;
                    
                    KmlLAve=(KmlL(ii,jj)*KmlL(ii,jj+1)*KmlL(ii+1,jj+1)*KmlL(ii+1,jj))^0.25;
                    DtlLAve=(DtlL(ii,jj)*DtlL(ii,jj+1)*DtlL(ii+1,jj+1)*DtlL(ii+1,jj))^0.25;
                    
                    % Basis 1
                    if(ii==1||jj==1)
                        A(Node1,Node1)=1;
                        B1(Node1,1)=MsBaHead1(ii,jj);
                        B2(Node1,1)=MsBaHead2(ii,jj);
                        B3(Node1,1)=MsBaHead3(ii,jj);
                        B4(Node1,1)=MsBaHead4(ii,jj);
                    else
                        A(Node1,Node1)=A(Node1,Node1)+(1/3+1/3)*KmlLAve;
                        A(Node1,Node2)=A(Node1,Node2)+(-1/3+1/6)*KmlLAve;
                        A(Node1,Node3)=A(Node1,Node3)+(-1/6-1/6)*KmlLAve;
                        A(Node1,Node4)=A(Node1,Node4)+(1/6-1/3)*KmlLAve;
                        B1(Node1,1)=B1(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node1,1)=B2(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node1,1)=B3(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node1,1)=B4(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 2
                    if(ii==1||jj==multiscale)
                        A(Node2,Node2)=1;
                        B1(Node2,1)=MsBaHead1(ii,jj+1);
                        B2(Node2,1)=MsBaHead2(ii,jj+1);
                        B3(Node2,1)=MsBaHead3(ii,jj+1);
                        B4(Node2,1)=MsBaHead4(ii,jj+1);
                    else
                        A(Node2,Node1)=A(Node2,Node1)+(-1/3+1/6)*KmlLAve;
                        A(Node2,Node2)=A(Node2,Node2)+(1/3+1/3)*KmlLAve;
                        A(Node2,Node3)=A(Node2,Node3)+(1/6-1/3)*KmlLAve;
                        A(Node2,Node4)=A(Node2,Node4)+(-1/6-1/6)*KmlLAve;
                        B1(Node2,1)=B1(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node2,1)=B2(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node2,1)=B3(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node2,1)=B4(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 3
                    if(ii==multiscale||jj==multiscale)
                        A(Node3,Node3)=1;
                        B1(Node3,1)=MsBaHead1(ii+1,jj+1);
                        B2(Node3,1)=MsBaHead2(ii+1,jj+1);
                        B3(Node3,1)=MsBaHead3(ii+1,jj+1);
                        B4(Node3,1)=MsBaHead4(ii+1,jj+1);
                    else
                        A(Node3,Node1)=A(Node3,Node1)+(-1/6-1/6)*KmlLAve;
                        A(Node3,Node2)=A(Node3,Node2)+(1/6-1/3)*KmlLAve;
                        A(Node3,Node3)=A(Node3,Node3)+(1/3+1/3)*KmlLAve;
                        A(Node3,Node4)=A(Node3,Node4)+(-1/3+1/6)*KmlLAve;
                        B1(Node3,1)=B1(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node3,1)=B2(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node3,1)=B3(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node3,1)=B4(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 4
                    if(ii==multiscale||jj==1)
                        A(Node4,Node4)=1;
                        B1(Node4,1)=MsBaHead1(ii+1,jj);
                        B2(Node4,1)=MsBaHead2(ii+1,jj);
                        B3(Node4,1)=MsBaHead3(ii+1,jj);
                        B4(Node4,1)=MsBaHead4(ii+1,jj);
                    else
                        A(Node4,Node1)=A(Node4,Node1)+(1/6-1/3)*KmlLAve;
                        A(Node4,Node2)=A(Node4,Node2)+(-1/6-1/6)*KmlLAve;
                        A(Node4,Node3)=A(Node4,Node3)+(-1/3+1/6)*KmlLAve;
                        A(Node4,Node4)=A(Node4,Node4)+(1/3+1/3)*KmlLAve;
                        B1(Node4,1)=B1(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node4,1)=B2(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node4,1)=B3(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node4,1)=B4(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                end
            end
            KK1=A\B1;
            KK2=A\B2;
            KK3=A\B3;
            KK4=A\B4;
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaHead1(ii,jj)=KK1((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead2(ii,jj)=KK2((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead3(ii,jj)=KK3((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead4(ii,jj)=KK4((ii-1)*(multiscale+1)+jj,1);
                end
            end
            
            clear A B1 B2 B3 B4 KK1 KK2 KK3 KK4;
            
            % make sure the 0 boundary is exactly 0 (in case)
            MsBaHead1(multiscale+1,1)=0;    MsBaHead1(1,multiscale+1)=0;
            MsBaHead2(1,1)=0;               MsBaHead2(multiscale+1,multiscale+1)=0;
            MsBaHead3(1,multiscale+1)=0;    MsBaHead3(multiscale+1,1)=0;
            MsBaHead4(1,1)=0;               MsBaHead4(multiscale+1,multiscale+1)=0;
                 
            % give the gradient
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaHeadGDx1(ii,jj)=(MsBaHead1(ii,jj+1)-MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)-MsBaHead1(ii+1,jj))/2/dhf;
                    MsBaHeadGDx2(ii,jj)=(MsBaHead2(ii,jj+1)-MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)-MsBaHead2(ii+1,jj))/2/dhf;
                    MsBaHeadGDx3(ii,jj)=(MsBaHead3(ii,jj+1)-MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)-MsBaHead3(ii+1,jj))/2/dhf;
                    MsBaHeadGDx4(ii,jj)=(MsBaHead4(ii,jj+1)-MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)-MsBaHead4(ii+1,jj))/2/dhf;
                    MsBaHeadGDy1(ii,jj)=(MsBaHead1(ii+1,jj)-MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)-MsBaHead1(ii,jj+1))/2/dhf;
                    MsBaHeadGDy2(ii,jj)=(MsBaHead2(ii+1,jj)-MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)-MsBaHead2(ii,jj+1))/2/dhf;
                    MsBaHeadGDy3(ii,jj)=(MsBaHead3(ii+1,jj)-MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)-MsBaHead3(ii,jj+1))/2/dhf;
                    MsBaHeadGDy4(ii,jj)=(MsBaHead4(ii+1,jj)-MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)-MsBaHead4(ii,jj+1))/2/dhf;
                    
                    MsBaTempGDx1(ii,jj)=(MsBaTemp1(ii,jj+1)-MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)-MsBaTemp1(ii+1,jj))/2/dhf;
                    MsBaTempGDx2(ii,jj)=(MsBaTemp2(ii,jj+1)-MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)-MsBaTemp2(ii+1,jj))/2/dhf;
                    MsBaTempGDx3(ii,jj)=(MsBaTemp3(ii,jj+1)-MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)-MsBaTemp3(ii+1,jj))/2/dhf;
                    MsBaTempGDx4(ii,jj)=(MsBaTemp4(ii,jj+1)-MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)-MsBaTemp4(ii+1,jj))/2/dhf;
                    MsBaTempGDy1(ii,jj)=(MsBaTemp1(ii+1,jj)-MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)-MsBaTemp1(ii,jj+1))/2/dhf;
                    MsBaTempGDy2(ii,jj)=(MsBaTemp2(ii+1,jj)-MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)-MsBaTemp2(ii,jj+1))/2/dhf;
                    MsBaTempGDy3(ii,jj)=(MsBaTemp3(ii+1,jj)-MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)-MsBaTemp3(ii,jj+1))/2/dhf;
                    MsBaTempGDy4(ii,jj)=(MsBaTemp4(ii+1,jj)-MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)-MsBaTemp4(ii,jj+1))/2/dhf;
                    
                    MsBaHeadMe1(ii,jj)=(MsBaHead1(ii,jj+1)+MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)+MsBaHead1(ii+1,jj))/4;
                    MsBaHeadMe2(ii,jj)=(MsBaHead2(ii,jj+1)+MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)+MsBaHead2(ii+1,jj))/4;
                    MsBaHeadMe3(ii,jj)=(MsBaHead3(ii,jj+1)+MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)+MsBaHead3(ii+1,jj))/4;
                    MsBaHeadMe4(ii,jj)=(MsBaHead4(ii,jj+1)+MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)+MsBaHead4(ii+1,jj))/4;
                    MsBaTempMe1(ii,jj)=(MsBaTemp1(ii+1,jj)+MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)+MsBaTemp1(ii,jj+1))/4;
                    MsBaTempMe2(ii,jj)=(MsBaTemp2(ii+1,jj)+MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)+MsBaTemp2(ii,jj+1))/4;
                    MsBaTempMe3(ii,jj)=(MsBaTemp3(ii+1,jj)+MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)+MsBaTemp3(ii,jj+1))/4;
                    MsBaTempMe4(ii,jj)=(MsBaTemp4(ii+1,jj)+MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)+MsBaTemp4(ii,jj+1))/4;
                end
            end
            
            EleIndex=(i-1)*nh+j;
            MsBasisArray{EleIndex,1}=MsBaHead1;
            MsBasisArray{EleIndex,2}=MsBaHead2;
            MsBasisArray{EleIndex,3}=MsBaHead3;
            MsBasisArray{EleIndex,4}=MsBaHead4;
            MsBasisArray{EleIndex,5}=MsBaTemp1;
            MsBasisArray{EleIndex,6}=MsBaTemp2;
            MsBasisArray{EleIndex,7}=MsBaTemp3;
            MsBasisArray{EleIndex,8}=MsBaTemp4;
            
            MsBasisArrayMe{EleIndex,1}=MsBaHeadMe1;
            MsBasisArrayMe{EleIndex,2}=MsBaHeadMe2;
            MsBasisArrayMe{EleIndex,3}=MsBaHeadMe3;
            MsBasisArrayMe{EleIndex,4}=MsBaHeadMe4;
            MsBasisArrayMe{EleIndex,5}=MsBaTempMe1;
            MsBasisArrayMe{EleIndex,6}=MsBaTempMe2;
            MsBasisArrayMe{EleIndex,7}=MsBaTempMe3;
            MsBasisArrayMe{EleIndex,8}=MsBaTempMe4;
            
            MsBasisArrayGDx{EleIndex,1}=MsBaHeadGDx1;
            MsBasisArrayGDx{EleIndex,2}=MsBaHeadGDx2;
            MsBasisArrayGDx{EleIndex,3}=MsBaHeadGDx3;
            MsBasisArrayGDx{EleIndex,4}=MsBaHeadGDx4;
            MsBasisArrayGDx{EleIndex,5}=MsBaTempGDx1;
            MsBasisArrayGDx{EleIndex,6}=MsBaTempGDx2;
            MsBasisArrayGDx{EleIndex,7}=MsBaTempGDx3;
            MsBasisArrayGDx{EleIndex,8}=MsBaTempGDx4;
            
            MsBasisArrayGDy{EleIndex,1}=MsBaHeadGDy1;
            MsBasisArrayGDy{EleIndex,2}=MsBaHeadGDy2;
            MsBasisArrayGDy{EleIndex,3}=MsBaHeadGDy3;
            MsBasisArrayGDy{EleIndex,4}=MsBaHeadGDy4;
            MsBasisArrayGDy{EleIndex,5}=MsBaTempGDy1;
            MsBasisArrayGDy{EleIndex,6}=MsBaTempGDy2;
            MsBasisArrayGDy{EleIndex,7}=MsBaTempGDy3;
            MsBasisArrayGDy{EleIndex,8}=MsBaTempGDy4;
            
        end
    end 
    end

% ----------- end multiscale finite element basis -------------------------
    
    p=0;
    HeadCtt=HeadC;
    TempCtt=TempC;  
    
% ------------ start to assemble the finite element method ----------------    
    EleIndex=0;
    A=sparse(2*TotalNodeC,2*TotalNodeC);
    B=sparse(2*TotalNodeC,1);
    for i=1:nh
        for j=1:nh
            
            % -------------------- preparation part --------------------
            
            % extract node index

            EleIndex=EleIndex+1;
            NodeIndex1=MsEleArray(EleIndex,1); NodeIndex2=MsEleArray(EleIndex,2);
            NodeIndex3=MsEleArray(EleIndex,3); NodeIndex4=MsEleArray(EleIndex,4);
            
            % read the basis function matrix
            
            MsBaHeadMe1=MsBasisArrayMe{EleIndex,1}; MsBaHeadMe2=MsBasisArrayMe{EleIndex,2};
            MsBaHeadMe3=MsBasisArrayMe{EleIndex,3}; MsBaHeadMe4=MsBasisArrayMe{EleIndex,4};
            
            MsBaTempMe1=MsBasisArrayMe{EleIndex,5}; MsBaTempMe2=MsBasisArrayMe{EleIndex,6};
            MsBaTempMe3=MsBasisArrayMe{EleIndex,7}; MsBaTempMe4=MsBasisArrayMe{EleIndex,8};
            
            % read the gradient matrix
            
            MsBaHeadGDx1=MsBasisArrayGDx{EleIndex,1}; MsBaHeadGDx2=MsBasisArrayGDx{EleIndex,2};
            MsBaHeadGDx3=MsBasisArrayGDx{EleIndex,3}; MsBaHeadGDx4=MsBasisArrayGDx{EleIndex,4};
            
            MsBaTempGDx1=MsBasisArrayGDx{EleIndex,5}; MsBaTempGDx2=MsBasisArrayGDx{EleIndex,6};
            MsBaTempGDx3=MsBasisArrayGDx{EleIndex,7}; MsBaTempGDx4=MsBasisArrayGDx{EleIndex,8};
            
            MsBaHeadGDy1=MsBasisArrayGDy{EleIndex,1}; MsBaHeadGDy2=MsBasisArrayGDy{EleIndex,2};
            MsBaHeadGDy3=MsBasisArrayGDy{EleIndex,3}; MsBaHeadGDy4=MsBasisArrayGDy{EleIndex,4};
            
            MsBaTempGDy1=MsBasisArrayGDy{EleIndex,5}; MsBaTempGDy2=MsBasisArrayGDy{EleIndex,6};
            MsBaTempGDy3=MsBasisArrayGDy{EleIndex,7}; MsBaTempGDy4=MsBasisArrayGDy{EleIndex,8};
            
            % mean soil property across the cross element
            % Arithmetic mean?? Geometical mean?
            
            KmlAve=(KmlC(i,j)*KmlC(i+1,j)*KmlC(i,j+1)*KmlC(i+1,j+1))^0.25;
            DtlAve=(DtlC(i,j)*DtlC(i+1,j)*DtlC(i,j+1)*DtlC(i+1,j+1))^0.25;
            DmvAve=(DmvC(i,j)*DmvC(i+1,j)*DmvC(i,j+1)*DmvC(i+1,j+1))^0.25;
            DtvAve=(DtvC(i,j)*DtvC(i+1,j)*DtvC(i,j+1)*DtvC(i+1,j+1))^0.25;
            LamAve=(LamC(i,j)*LamC(i+1,j)*LamC(i,j+1)*LamC(i+1,j+1))^0.25;
            
            H1Ave=(H1C(i,j)+H1C(i+1,j)+H1C(i,j+1)+H1C(i+1,j+1))./4;
            H2Ave=(H2C(i,j)+H2C(i+1,j)+H2C(i,j+1)+H2C(i+1,j+1))./4;
            T1Ave=(T1C(i,j)+T1C(i+1,j)+T1C(i,j+1)+T1C(i+1,j+1))./4;
            T2Ave=(T2C(i,j)+T2C(i+1,j)+T2C(i,j+1)+T2C(i+1,j+1))./4;
            
            % advection part: determine the upwind temperature 
            % liquid transfer
            aaaa=KmlAve*(HeadC(i,j+1)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i+1,j))...
                +DtlAve*(TempC(i,j+1)-TempC(i,j)+TempC(i+1,j+1)-TempC(i+1,j));
            if(aaaa>0)                                  % upwind=right
                TupWindL(1,1)=TempC(i,j+1);
                TupWindL(2,1)=TempC(i,j+1);
                TupWindL(3,1)=TempC(i+1,j+1);
                TupWindL(4,1)=TempC(i+1,j+1);
            elseif(aaaa<0)                              % upwind=left
                TupWindL(1,1)=TempC(i,j);
                TupWindL(2,1)=TempC(i,j);
                TupWindL(3,1)=TempC(i+1,j);
                TupWindL(4,1)=TempC(i+1,j);
            else                                        % no upwind
                TupWindL(1,1)=0;
                TupWindL(2,1)=0;
                TupWindL(3,1)=0;
                TupWindL(4,1)=0;
            end
            bbbb=KmlAve*(HeadC(i+1,j)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i,j+1))...
                +DtlAve*(TempC(i+1,j)-TempC(i,j)+TempC(i+1,j+1)-TempC(i,j+1));
            if(bbbb>0)                                  % upwind=up
                TupWindL(1,2)=TempC(i+1,j);
                TupWindL(2,2)=TempC(i+1,j+1);
                TupWindL(3,2)=TempC(i+1,j+1);
                TupWindL(4,2)=TempC(i+1,j);
            elseif(bbbb<0)                              % upwind=down
                TupWindL(1,2)=TempC(i,j);
                TupWindL(2,2)=TempC(i,j+1);
                TupWindL(3,2)=TempC(i,j+1);
                TupWindL(4,2)=TempC(i,j);
            else                                        % no upwind
                TupWindL(1,2)=0;
                TupWindL(2,2)=0;
                TupWindL(3,2)=0;
                TupWindL(4,2)=0;
            end
            % vapor transfer
            cccc=DmvAve*(HeadC(i,j+1)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i+1,j))...
                +DtvAve*(TempC(i,j+1)-TempC(i,j)+TempC(i+1,j+1)-TempC(i+1,j));
            if(cccc>0)                                  % upwind=right
                TupWindV(1,1)=TempC(i,j+1);
                TupWindV(2,1)=TempC(i,j+1);
                TupWindV(3,1)=TempC(i+1,j+1);
                TupWindV(4,1)=TempC(i+1,j+1);
            elseif(cccc<0)                              % upwind=left
                TupWindV(1,1)=TempC(i,j);
                TupWindV(2,1)=TempC(i,j);
                TupWindV(3,1)=TempC(i+1,j);
                TupWindV(4,1)=TempC(i+1,j);
            else                                        % no upwind
                TupWindV(1,1)=0;
                TupWindV(2,1)=0;
                TupWindV(3,1)=0;
                TupWindV(4,1)=0;
            end
            dddd=DmvAve*(HeadC(i+1,j)-HeadC(i,j)+HeadC(i+1,j+1)-HeadC(i,j+1))...
                +DtvAve*(TempC(i+1,j)-TempC(i,j)+TempC(i+1,j+1)-TempC(i,j+1));
            if(dddd>0)                                  % upwind=up
                TupWindV(1,2)=TempC(i+1,j);
                TupWindV(2,2)=TempC(i+1,j+1);
                TupWindV(3,2)=TempC(i+1,j+1);
                TupWindV(4,2)=TempC(i+1,j);
            elseif(dddd<0)                              % upwind=down
                TupWindV(1,2)=TempC(i,j);
                TupWindV(2,2)=TempC(i,j+1);
                TupWindV(3,2)=TempC(i,j+1);
                TupWindV(4,2)=TempC(i,j);
            else                                        % no upwind
                TupWindV(1,2)=0;
                TupWindV(2,2)=0;
                TupWindV(3,2)=0;
                TupWindV(4,2)=0;
            end
            
            % -------------------- establish linear system --------------------
            
            % constructing the diffusive part based on MsFEM
            % Node 1
            if(MsNodeArray(i,j,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
                aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix: diffusion part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx1,'all')+sum(MsBaHeadGDy1.*MsTestGDy1,'all')).*dhf2.*dt;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx1,'all')+sum(MsBaHeadGDy2.*MsTestGDy1,'all')).*dhf2.*dt;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx1,'all')+sum(MsBaHeadGDy3.*MsTestGDy1,'all')).*dhf2.*dt;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx1,'all')+sum(MsBaHeadGDy4.*MsTestGDy1,'all')).*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx1,'all')+sum(MsBaTempGDy1.*MsTestGDy1,'all')).*dhf2.*dt;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx1,'all')+sum(MsBaTempGDy2.*MsTestGDy1,'all')).*dhf2.*dt;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx1,'all')+sum(MsBaTempGDy3.*MsTestGDy1,'all')).*dhf2.*dt;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx1,'all')+sum(MsBaTempGDy4.*MsTestGDy1,'all')).*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx1,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy1,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx1,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy1,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx1,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy1,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx1,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy1,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx1,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy1,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx1,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy1,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx1,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy1,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx1,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy1,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                
                % vapor part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i,j,2)==1)  % bottom boundary  

                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=TDown;
                                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i,j,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex1+TotalNodeC,1)=TUp;                
                
                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf2.*dt;
                
                A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 2
            if(MsNodeArray(i,j+1,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
                aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx2,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy2,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx2,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy2,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx2,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy2,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx2,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy2,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx2,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy2,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx2,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy2,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx2,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy2,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx2,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy2,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                
                % vapor part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i,j+1,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                             
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=TDown;
                
                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i,j+1,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;
                             
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex2+TotalNodeC,1)=TUp; 
                                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;
                
                A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 3
            if(MsNodeArray(i+1,j+1,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
                aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                      
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx3,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy3,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx3,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy3,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx3,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy3,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx3,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy3,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx3,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy3,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx3,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy3,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx3,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy3,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx3,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy3,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                
                % vapor part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i+1,j+1,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=TDown;
                                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i+1,j+1,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;
                                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex3+TotalNodeC,1)=TUp;
                
                               
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;
                
                A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
            % Node 4
            if(MsNodeArray(i+1,j,2)==0)  % no need to consider the boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+T2Ave*dddd;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)...
                    +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                
                aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)+...
                    +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                
                                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;
                
                % stiffness matrix: advection part
                
                % liquid part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx4,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy4,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx4,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy4,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx4,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy4,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx4,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy4,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx4,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy4,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx4,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy4,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx4,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy4,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx4,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy4,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;
                
                % vapor part
                
                aaaa=(sum(MsBaHeadGDx1.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaHeadGDx2.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaHeadGDx3.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaHeadGDx4.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+DmvAve*dddd;                
                
                aaaa=(sum(MsBaTempGDx1.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                bbbb=(sum(MsBaTempGDx2.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                cccc=(sum(MsBaTempGDx3.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                dddd=(sum(MsBaTempGDx4.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                
                A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;
                
            elseif(MsNodeArray(i+1,j,2)==1)  % bottom boundary  
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                               
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=TDown;
                
                                
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                
            elseif(MsNodeArray(i+1,j,2)==2)  % upper boundary
                
                % mass matrix part
                aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;
                               
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=0;
                
                aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;
                
                A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;
                
                % mass vector
                B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                B(NodeIndex4+TotalNodeC,1)=TUp;
                              
                % stiffness matrix
                aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;
                
                aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;
                
                A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
            else    
            end
            
        end
    end
    
    KK=A\B;
    
    for i=1:nh+1
        for j=1:nh+1
            HeadCtt(i,j)=min(KK(MsNodeArray(i,j,1),1),-13.0);
            TempCtt(i,j)=KK(MsNodeArray(i,j,1)+TotalNodeC,1);
        end
    end
    
    % refine the solution to fine grid 200*200
    
    EleIndex=0;
    for i=1:nh
        for j=1:nh
            EleIndex=EleIndex+1;
            MsBaHead1=MsBasisArray{EleIndex,1};
            MsBaHead2=MsBasisArray{EleIndex,2};
            MsBaHead3=MsBasisArray{EleIndex,3};
            MsBaHead4=MsBasisArray{EleIndex,4};
            MsBaTemp1=MsBasisArray{EleIndex,5};
            MsBaTemp2=MsBasisArray{EleIndex,6};
            MsBaTemp3=MsBasisArray{EleIndex,7};
            MsBaTemp4=MsBasisArray{EleIndex,8};
            
            il=(i-1)*multiscale;
            jl=(j-1)*multiscale;
            
            for ii=1:multiscale+1
                for jj=1:multiscale+1
                    Headtt(il+ii,jl+jj)=HeadCtt(i,j)*MsBaHead1(ii,jj)...
                        +HeadCtt(i,j+1)*MsBaHead2(ii,jj)...
                        +HeadCtt(i+1,j+1)*MsBaHead3(ii,jj)...
                        +HeadCtt(i+1,j)*MsBaHead4(ii,jj);
                    Temptt(il+ii,jl+jj)=TempCtt(i,j)*MsBaTemp1(ii,jj)...
                        +TempCtt(i,j+1)*MsBaTemp2(ii,jj)...
                        +TempCtt(i+1,j+1)*MsBaTemp3(ii,jj)...
                        +TempCtt(i+1,j)*MsBaTemp4(ii,jj);
                end
            end

        end
    end


            
    while p<5
        p=p+1;
        HeadCpp=HeadCtt;
        TempCpp=TempCtt;
        HeadCt=0.5.*(HeadCtt+HeadC);
        TempCt=0.5.*(TempCtt+TempC);
        
        Headpp=Headtt;
        Temppp=Temptt;
        Headt=0.5.*(Headtt+Head);
        Tempt=0.5.*(Temptt+Temp);
                
        for i=1:nhT+1 
            for j=1:nhT+1
                KmlG(i,j)=RF_Ks(i,j).*FunKml(Headt(i,j),Tempt(i,j));
                DtlG(i,j)=RF_Ks(i,j).*FunDtl(Headt(i,j),Tempt(i,j));
                DmvG(i,j)=FunDmv(Headt(i,j),Tempt(i,j));
                DtvG(i,j)=FunDtv(Headt(i,j),Tempt(i,j));
                LamG(i,j)=RF_La(i,j).*FunLambda_Bulk(Headt(i,j),Tempt(i,j));
            end
        end
        for i=1:nh+1 
            for j=1:nh+1
                KmlC(i,j)=KmlG((i-1)*multiscale+1,(j-1)*multiscale+1);
                DtlC(i,j)=DtlG((i-1)*multiscale+1,(j-1)*multiscale+1);
                DmvC(i,j)=DmvG((i-1)*multiscale+1,(j-1)*multiscale+1);
                DtvC(i,j)=DtvG((i-1)*multiscale+1,(j-1)*multiscale+1);
                LamC(i,j)=LamG((i-1)*multiscale+1,(j-1)*multiscale+1);
                H1C(i,j)=FunH1(HeadCt(i,j),TempCt(i,j));
                H2C(i,j)=FunH2(HeadCt(i,j),TempCt(i,j));
                T1C(i,j)=FunT1(HeadCt(i,j),TempCt(i,j));
                T2C(i,j)=FunT2(HeadCt(i,j),TempCt(i,j));
            end
        end
        
        
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for i=1:nh 
        for j=1:nh
            
            KmlL=KmlG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            DtlL=DtlG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            LamL=LamG((i-1)*multiscale+1:i*multiscale+1,(j-1)*multiscale+1:j*multiscale+1);
            
            MsBaHead1=zeros(multiscale+1,multiscale+1);
            MsBaHead2=zeros(multiscale+1,multiscale+1);
            MsBaHead3=zeros(multiscale+1,multiscale+1);
            MsBaHead4=zeros(multiscale+1,multiscale+1);
            MsBaTemp1=zeros(multiscale+1,multiscale+1);
            MsBaTemp2=zeros(multiscale+1,multiscale+1);
            MsBaTemp3=zeros(multiscale+1,multiscale+1);
            MsBaTemp4=zeros(multiscale+1,multiscale+1);
            
            MsBaHead1(1,1)=1;MsBaTemp1(1,1)=1;
            MsBaHead2(1,multiscale+1)=1;MsBaTemp2(1,multiscale+1)=1;
            MsBaHead3(multiscale+1,multiscale+1)=1;MsBaTemp3(multiscale+1,multiscale+1)=1;
            MsBaHead4(multiscale+1,1)=1; MsBaTemp4(multiscale+1,1)=1;
            
            % first do the temperature basis function

            % numerically solve the boundary condition
            % boundary I
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(LamL(1,jj)*LamL(1,jj-1));
                A(jj,jj+1)=sqrt(LamL(1,jj)*LamL(1,jj+1));
                A(jj,jj)=-sqrt(LamL(1,jj)*LamL(1,jj-1))...
                    -sqrt(LamL(1,jj)*LamL(1,jj+1));
                B(jj,1)=0;
            end
            KKI=A\B;
            for jj=1:multiscale+1
                MsBaTemp1(1,jj)=KKI(jj);
                MsBaTemp2(1,jj)=1-MsBaTemp1(1,jj);
            end
            
            % boundary II
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(LamL(ii,multiscale+1)*LamL(ii-1,multiscale+1));
                A(ii,ii+1)=sqrt(LamL(ii,multiscale+1)*LamL(ii+1,multiscale+1));
                A(ii,ii)=-sqrt(LamL(ii,multiscale+1)*LamL(ii-1,multiscale+1))...
                    -sqrt(LamL(ii,multiscale+1)*LamL(ii+1,multiscale+1));
                B(ii,1)=0;
            end
            KKII=A\B;
            for ii=1:multiscale+1
                MsBaTemp2(ii,multiscale+1)=KKII(ii);
                MsBaTemp3(ii,multiscale+1)=1-MsBaTemp2(ii,multiscale+1);
            end
            
            % boundary III
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj-1));
                A(jj,jj+1)=sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj+1));
                A(jj,jj)=-sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj-1))...
                    -sqrt(LamL(multiscale+1,jj)*LamL(multiscale+1,jj+1));
                B(jj,1)=0;
            end
            KKIII=A\B;
            for jj=1:multiscale+1
                MsBaTemp4(multiscale+1,jj)=KKIII(jj);
                MsBaTemp3(multiscale+1,jj)=1-MsBaTemp4(multiscale+1,jj);
            end
            
            % boundary IV
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(LamL(ii,1)*LamL(ii-1,1));
                A(ii,ii+1)=sqrt(LamL(ii,1)*LamL(ii+1,1));
                A(ii,ii)=-sqrt(LamL(ii,1)*LamL(ii-1,1))...
                    -sqrt(LamL(ii,1)*LamL(ii+1,1));
                B(ii,1)=0;
            end
            KKIV=A\B;
            for ii=1:multiscale+1
                MsBaTemp1(ii,1)=KKIV(ii);
                MsBaTemp4(ii,1)=1-MsBaTemp1(ii,1);
            end
            
            clear A B KKI KKII KKIII KKIV;
                        
            A=sparse(TotalNodeL,TotalNodeL);
            B1=sparse(TotalNodeL,1);
            B2=sparse(TotalNodeL,1);
            B3=sparse(TotalNodeL,1);
            B4=sparse(TotalNodeL,1);
            for ii=1:multiscale
                for jj=1:multiscale
                    Node1=(ii-1)*(multiscale+1)+jj;
                    Node2=(ii-1)*(multiscale+1)+jj+1;
                    Node3=ii*(multiscale+1)+jj+1;
                    Node4=ii*(multiscale+1)+jj;
%                    LamLAve=(LamL(ii,jj)+LamL(ii,jj+1)+LamL(ii+1,jj+1)+LamL(ii+1,jj))./4;
                    
                    LamLAve=(LamL(ii,jj)*LamL(ii,jj+1)*LamL(ii+1,jj+1)*LamL(ii+1,jj))^0.25;
                    
                    % Basis 1
                    if(ii==1||jj==1)
                        A(Node1,Node1)=1;
                        B1(Node1,1)=MsBaTemp1(ii,jj);
                        B2(Node1,1)=MsBaTemp2(ii,jj);
                        B3(Node1,1)=MsBaTemp3(ii,jj);
                        B4(Node1,1)=MsBaTemp4(ii,jj);
                    else
                        A(Node1,Node1)=A(Node1,Node1)+(1/3+1/3)*LamLAve;
                        A(Node1,Node2)=A(Node1,Node2)+(-1/3+1/6)*LamLAve;
                        A(Node1,Node3)=A(Node1,Node3)+(-1/6-1/6)*LamLAve;
                        A(Node1,Node4)=A(Node1,Node4)+(1/6-1/3)*LamLAve;
                        B1(Node1,1)=0;
                        B2(Node1,1)=0;
                        B3(Node1,1)=0;
                        B4(Node1,1)=0;
                    end
                    
                    % Basis 2
                    if(ii==1||jj==multiscale)
                        A(Node2,Node2)=1;
                        B1(Node2,1)=MsBaTemp1(ii,jj+1);
                        B2(Node2,1)=MsBaTemp2(ii,jj+1);
                        B3(Node2,1)=MsBaTemp3(ii,jj+1);
                        B4(Node2,1)=MsBaTemp4(ii,jj+1);
                    else
                        A(Node2,Node1)=A(Node2,Node1)+(-1/3+1/6)*LamLAve;
                        A(Node2,Node2)=A(Node2,Node2)+(1/3+1/3)*LamLAve;
                        A(Node2,Node3)=A(Node2,Node3)+(1/6-1/3)*LamLAve;
                        A(Node2,Node4)=A(Node2,Node4)+(-1/6-1/6)*LamLAve;
                        B1(Node2,1)=0;
                        B2(Node2,1)=0;
                        B3(Node2,1)=0;
                        B4(Node2,1)=0;
                    end
                    
                    % Basis 3
                    if(ii==multiscale||jj==multiscale)
                        A(Node3,Node3)=1;
                        B1(Node3,1)=MsBaTemp1(ii+1,jj+1);
                        B2(Node3,1)=MsBaTemp2(ii+1,jj+1);
                        B3(Node3,1)=MsBaTemp3(ii+1,jj+1);
                        B4(Node3,1)=MsBaTemp4(ii+1,jj+1);
                    else
                        A(Node3,Node1)=A(Node3,Node1)+(-1/6-1/6)*LamLAve;
                        A(Node3,Node2)=A(Node3,Node2)+(1/6-1/3)*LamLAve;
                        A(Node3,Node3)=A(Node3,Node3)+(1/3+1/3)*LamLAve;
                        A(Node3,Node4)=A(Node3,Node4)+(-1/3+1/6)*LamLAve;
                        B1(Node3,1)=0;
                        B2(Node3,1)=0;
                        B3(Node3,1)=0;
                        B4(Node3,1)=0;
                    end
                    
                    % Basis 4
                    if(ii==multiscale||jj==1)
                        A(Node4,Node4)=1;
                        B1(Node4,1)=MsBaTemp1(ii+1,jj);
                        B2(Node4,1)=MsBaTemp2(ii+1,jj);
                        B3(Node4,1)=MsBaTemp3(ii+1,jj);
                        B4(Node4,1)=MsBaTemp4(ii+1,jj);
                    else
                        A(Node4,Node1)=A(Node4,Node1)+(1/6-1/3)*LamLAve;
                        A(Node4,Node2)=A(Node4,Node2)+(-1/6-1/6)*LamLAve;
                        A(Node4,Node3)=A(Node4,Node3)+(-1/3+1/6)*LamLAve;
                        A(Node4,Node4)=A(Node4,Node4)+(1/3+1/3)*LamLAve;
                        B1(Node4,1)=0;
                        B2(Node4,1)=0;
                        B3(Node4,1)=0;
                        B4(Node4,1)=0;
                    end
                end
            end
            KK1=A\B1;
            KK2=A\B2;
            KK3=A\B3;
            KK4=A\B4;
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaTemp1(ii,jj)=KK1((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp2(ii,jj)=KK2((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp3(ii,jj)=KK3((ii-1)*(multiscale+1)+jj,1);
                    MsBaTemp4(ii,jj)=KK4((ii-1)*(multiscale+1)+jj,1);
                end
            end
            
            clear A B1 B2 B3 B4 KK1 KK2 KK3 KK4;
            
            % make sure the 0 boundary is exactly 0 (in case)
            MsBaTemp1(multiscale+1,1)=0;    MsBaTemp1(1,multiscale+1)=0;
            MsBaTemp2(1,1)=0;               MsBaTemp2(multiscale+1,multiscale+1)=0;
            MsBaTemp3(1,multiscale+1)=0;    MsBaTemp3(multiscale+1,1)=0;
            MsBaTemp4(1,1)=0;               MsBaTemp4(multiscale+1,multiscale+1)=0;
            
            % second do the water content basis function
            % why two basis should be aligned? i.e.,
            % MsBaHeadx \sim MsBaTempx, if think head and temp as a long
            % vector and each spatial location correspond two 1 of water
            % and temp associated. 

            % numerically solve the boundary condition
            % boundary I
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(KmlL(1,jj)*KmlL(1,jj-1));
                A(jj,jj+1)=sqrt(KmlL(1,jj)*KmlL(1,jj+1));
                A(jj,jj)=-sqrt(KmlL(1,jj)*KmlL(1,jj-1))...
                    -sqrt(KmlL(1,jj)*KmlL(1,jj+1));
                B(jj,1)=(sqrt(DtlL(1,jj)*DtlL(1,jj-1))*(MsBaTemp1(1,jj)-MsBaTemp1(1,jj-1))...
                    +sqrt(DtlL(1,jj)*DtlL(1,jj+1))*(MsBaTemp1(1,jj)-MsBaTemp1(1,jj+1)))...
                    *var_xi;
            end
            KKI=A\B;
            for jj=1:multiscale+1
                MsBaHead1(1,jj)=min(max(KKI(jj),0),1);
                MsBaHead2(1,jj)=1-MsBaHead1(1,jj);
            end
            
            % boundary II
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(KmlL(ii,multiscale+1)*KmlL(ii-1,multiscale+1));
                A(ii,ii+1)=sqrt(KmlL(ii,multiscale+1)*KmlL(ii+1,multiscale+1));
                A(ii,ii)=-sqrt(KmlL(ii,multiscale+1)*KmlL(ii-1,multiscale+1))...
                    -sqrt(KmlL(ii,multiscale+1)*KmlL(ii+1,multiscale+1));
                B(ii,1)=(sqrt(DtlL(ii,multiscale+1)*DtlL(ii-1,multiscale+1))...
                    *(MsBaTemp2(ii,multiscale+1)-MsBaTemp2(ii-1,multiscale-1))...
                    +sqrt(DtlL(ii,multiscale+1)*DtlL(ii+1,multiscale+1))...
                    *(MsBaTemp2(ii,multiscale+1)-MsBaTemp2(ii+1,multiscale-1)))...
                    *var_xi;
            end
            KKII=A\B;
            for ii=1:multiscale+1
                MsBaHead2(ii,multiscale+1)=min(max(KKII(ii),0),1);
                MsBaHead3(ii,multiscale+1)=1-MsBaHead2(ii,multiscale+1);
            end
            
            % boundary III
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for jj=2:multiscale
                A(jj,jj-1)=sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj-1));
                A(jj,jj+1)=sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj+1));
                A(jj,jj)=-sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj-1))...
                    -sqrt(KmlL(multiscale+1,jj)*KmlL(multiscale+1,jj+1));
                B(jj,1)=(sqrt(DtlL(multiscale+1,jj)*DtlL(multiscale+1,jj-1))...
                    *(MsBaTemp4(multiscale+1,jj)-MsBaTemp4(multiscale+1,jj-1))...
                    +sqrt(DtlL(multiscale+1,jj)*DtlL(multiscale+1,jj+1))...
                    *(MsBaTemp4(multiscale+1,jj)-MsBaTemp4(multiscale+1,jj+1)))...
                    *var_xi;
            end
            KKIII=A\B;
            for jj=1:multiscale+1
                MsBaHead4(multiscale+1,jj)=min(max(KKIII(jj),0),1);
                MsBaHead3(multiscale+1,jj)=1-MsBaHead4(multiscale+1,jj);
            end
            
            % boundary IV
            A=sparse(multiscale+1,multiscale+1);
            B=sparse(multiscale+1,1);
            A(1,1)=1;B(1,1)=1;
            A(multiscale+1,multiscale+1)=1;B(multiscale+1,1)=0;
            for ii=2:multiscale
                A(ii,ii-1)=sqrt(KmlL(ii,1)*KmlL(ii-1,1));
                A(ii,ii+1)=sqrt(KmlL(ii,1)*KmlL(ii+1,1));
                A(ii,ii)=-sqrt(KmlL(ii,1)*KmlL(ii-1,1))...
                    -sqrt(KmlL(ii,1)*KmlL(ii+1,1));
                B(ii,1)=(sqrt(KmlL(ii,1)*KmlL(ii-1,1))...
                    *(MsBaTemp1(ii,1)-MsBaTemp1(ii-1,1))...
                    +sqrt(KmlL(ii,1)*KmlL(ii+1,1))...
                    *(MsBaTemp1(ii,1)-MsBaTemp1(ii+1,1)))...
                    *var_xi;
            end
            KKIV=A\B;
            for ii=1:multiscale+1
                MsBaHead1(ii,1)=min(max(KKIV(ii),0),1);
                MsBaHead4(ii,1)=1-MsBaHead1(ii,1);
            end
            
            clear A B KKI KKII KKIII KKIV;
                        
            A=sparse(TotalNodeL,TotalNodeL);
            B1=sparse(TotalNodeL,1);
            B2=sparse(TotalNodeL,1);
            B3=sparse(TotalNodeL,1);
            B4=sparse(TotalNodeL,1);
            for ii=1:multiscale
                for jj=1:multiscale
                    Node1=(ii-1)*(multiscale+1)+jj;
                    Node2=(ii-1)*(multiscale+1)+jj+1;
                    Node3=ii*(multiscale+1)+jj+1;
                    Node4=ii*(multiscale+1)+jj;
                    
%                     KmlLAve=(KmlL(ii,jj)+KmlL(ii,jj+1)+KmlL(ii+1,jj+1)+KmlL(ii+1,jj))./4;
%                     DtlLAve=(DtlL(ii,jj)+DtlL(ii,jj+1)+DtlL(ii+1,jj+1)+DtlL(ii+1,jj))./4;
                    
                    KmlLAve=(KmlL(ii,jj)*KmlL(ii,jj+1)*KmlL(ii+1,jj+1)*KmlL(ii+1,jj))^0.25;
                    DtlLAve=(DtlL(ii,jj)*DtlL(ii,jj+1)*DtlL(ii+1,jj+1)*DtlL(ii+1,jj))^0.25;
                    
                    % Basis 1
                    if(ii==1||jj==1)
                        A(Node1,Node1)=1;
                        B1(Node1,1)=MsBaHead1(ii,jj);
                        B2(Node1,1)=MsBaHead2(ii,jj);
                        B3(Node1,1)=MsBaHead3(ii,jj);
                        B4(Node1,1)=MsBaHead4(ii,jj);
                    else
                        A(Node1,Node1)=A(Node1,Node1)+(1/3+1/3)*KmlLAve;
                        A(Node1,Node2)=A(Node1,Node2)+(-1/3+1/6)*KmlLAve;
                        A(Node1,Node3)=A(Node1,Node3)+(-1/6-1/6)*KmlLAve;
                        A(Node1,Node4)=A(Node1,Node4)+(1/6-1/3)*KmlLAve;
                        B1(Node1,1)=B1(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node1,1)=B2(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node1,1)=B3(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node1,1)=B4(Node1,1)+(-(1/3+1/3)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 2
                    if(ii==1||jj==multiscale)
                        A(Node2,Node2)=1;
                        B1(Node2,1)=MsBaHead1(ii,jj+1);
                        B2(Node2,1)=MsBaHead2(ii,jj+1);
                        B3(Node2,1)=MsBaHead3(ii,jj+1);
                        B4(Node2,1)=MsBaHead4(ii,jj+1);
                    else
                        A(Node2,Node1)=A(Node2,Node1)+(-1/3+1/6)*KmlLAve;
                        A(Node2,Node2)=A(Node2,Node2)+(1/3+1/3)*KmlLAve;
                        A(Node2,Node3)=A(Node2,Node3)+(1/6-1/3)*KmlLAve;
                        A(Node2,Node4)=A(Node2,Node4)+(-1/6-1/6)*KmlLAve;
                        B1(Node2,1)=B1(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node2,1)=B2(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node2,1)=B3(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node2,1)=B4(Node2,1)+(-(-1/3+1/6)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 3
                    if(ii==multiscale||jj==multiscale)
                        A(Node3,Node3)=1;
                        B1(Node3,1)=MsBaHead1(ii+1,jj+1);
                        B2(Node3,1)=MsBaHead2(ii+1,jj+1);
                        B3(Node3,1)=MsBaHead3(ii+1,jj+1);
                        B4(Node3,1)=MsBaHead4(ii+1,jj+1);
                    else
                        A(Node3,Node1)=A(Node3,Node1)+(-1/6-1/6)*KmlLAve;
                        A(Node3,Node2)=A(Node3,Node2)+(1/6-1/3)*KmlLAve;
                        A(Node3,Node3)=A(Node3,Node3)+(1/3+1/3)*KmlLAve;
                        A(Node3,Node4)=A(Node3,Node4)+(-1/3+1/6)*KmlLAve;
                        B1(Node3,1)=B1(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node3,1)=B2(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node3,1)=B3(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node3,1)=B4(Node3,1)+(-(-1/6-1/6)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(1/6-1/3)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                    
                    % Basis 4
                    if(ii==multiscale||jj==1)
                        A(Node4,Node4)=1;
                        B1(Node4,1)=MsBaHead1(ii+1,jj);
                        B2(Node4,1)=MsBaHead2(ii+1,jj);
                        B3(Node4,1)=MsBaHead3(ii+1,jj);
                        B4(Node4,1)=MsBaHead4(ii+1,jj);
                    else
                        A(Node4,Node1)=A(Node4,Node1)+(1/6-1/3)*KmlLAve;
                        A(Node4,Node2)=A(Node4,Node2)+(-1/6-1/6)*KmlLAve;
                        A(Node4,Node3)=A(Node4,Node3)+(-1/3+1/6)*KmlLAve;
                        A(Node4,Node4)=A(Node4,Node4)+(1/3+1/3)*KmlLAve;
                        B1(Node4,1)=B1(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp1(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp1(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp1(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp1(ii+1,jj))*var_xi;
                        B2(Node4,1)=B2(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp2(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp2(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp2(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp2(ii+1,jj))*var_xi;
                        B3(Node4,1)=B3(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp3(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp3(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp3(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp3(ii+1,jj))*var_xi;
                        B4(Node4,1)=B4(Node4,1)+(-(1/6-1/3)*DtlLAve*MsBaTemp4(ii,jj)...
                            -(-1/6-1/6)*DtlLAve*MsBaTemp4(ii,jj+1)...
                            -(-1/3+1/6)*DtlLAve*MsBaTemp4(ii+1,jj+1)...
                            -(1/3+1/3)*DtlLAve*MsBaTemp4(ii+1,jj))*var_xi;
                    end
                end
            end
            KK1=A\B1;
            KK2=A\B2;
            KK3=A\B3;
            KK4=A\B4;
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaHead1(ii,jj)=KK1((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead2(ii,jj)=KK2((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead3(ii,jj)=KK3((ii-1)*(multiscale+1)+jj,1);
                    MsBaHead4(ii,jj)=KK4((ii-1)*(multiscale+1)+jj,1);
                end
            end
            
            clear A B1 B2 B3 B4 KK1 KK2 KK3 KK4;
            
            % make sure the 0 boundary is exactly 0 (in case)
            MsBaHead1(multiscale+1,1)=0;    MsBaHead1(1,multiscale+1)=0;
            MsBaHead2(1,1)=0;               MsBaHead2(multiscale+1,multiscale+1)=0;
            MsBaHead3(1,multiscale+1)=0;    MsBaHead3(multiscale+1,1)=0;
            MsBaHead4(1,1)=0;               MsBaHead4(multiscale+1,multiscale+1)=0;
                 
            % give the gradient
            for ii=1:multiscale
                for jj=1:multiscale
                    MsBaHeadGDx1(ii,jj)=(MsBaHead1(ii,jj+1)-MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)-MsBaHead1(ii+1,jj))/2/dhf;
                    MsBaHeadGDx2(ii,jj)=(MsBaHead2(ii,jj+1)-MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)-MsBaHead2(ii+1,jj))/2/dhf;
                    MsBaHeadGDx3(ii,jj)=(MsBaHead3(ii,jj+1)-MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)-MsBaHead3(ii+1,jj))/2/dhf;
                    MsBaHeadGDx4(ii,jj)=(MsBaHead4(ii,jj+1)-MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)-MsBaHead4(ii+1,jj))/2/dhf;
                    MsBaHeadGDy1(ii,jj)=(MsBaHead1(ii+1,jj)-MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)-MsBaHead1(ii,jj+1))/2/dhf;
                    MsBaHeadGDy2(ii,jj)=(MsBaHead2(ii+1,jj)-MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)-MsBaHead2(ii,jj+1))/2/dhf;
                    MsBaHeadGDy3(ii,jj)=(MsBaHead3(ii+1,jj)-MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)-MsBaHead3(ii,jj+1))/2/dhf;
                    MsBaHeadGDy4(ii,jj)=(MsBaHead4(ii+1,jj)-MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)-MsBaHead4(ii,jj+1))/2/dhf;
                    
                    MsBaTempGDx1(ii,jj)=(MsBaTemp1(ii,jj+1)-MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)-MsBaTemp1(ii+1,jj))/2/dhf;
                    MsBaTempGDx2(ii,jj)=(MsBaTemp2(ii,jj+1)-MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)-MsBaTemp2(ii+1,jj))/2/dhf;
                    MsBaTempGDx3(ii,jj)=(MsBaTemp3(ii,jj+1)-MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)-MsBaTemp3(ii+1,jj))/2/dhf;
                    MsBaTempGDx4(ii,jj)=(MsBaTemp4(ii,jj+1)-MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)-MsBaTemp4(ii+1,jj))/2/dhf;
                    MsBaTempGDy1(ii,jj)=(MsBaTemp1(ii+1,jj)-MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)-MsBaTemp1(ii,jj+1))/2/dhf;
                    MsBaTempGDy2(ii,jj)=(MsBaTemp2(ii+1,jj)-MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)-MsBaTemp2(ii,jj+1))/2/dhf;
                    MsBaTempGDy3(ii,jj)=(MsBaTemp3(ii+1,jj)-MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)-MsBaTemp3(ii,jj+1))/2/dhf;
                    MsBaTempGDy4(ii,jj)=(MsBaTemp4(ii+1,jj)-MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)-MsBaTemp4(ii,jj+1))/2/dhf;
                    
                    MsBaHeadMe1(ii,jj)=(MsBaHead1(ii,jj+1)+MsBaHead1(ii,jj)+MsBaHead1(ii+1,jj+1)+MsBaHead1(ii+1,jj))/4;
                    MsBaHeadMe2(ii,jj)=(MsBaHead2(ii,jj+1)+MsBaHead2(ii,jj)+MsBaHead2(ii+1,jj+1)+MsBaHead2(ii+1,jj))/4;
                    MsBaHeadMe3(ii,jj)=(MsBaHead3(ii,jj+1)+MsBaHead3(ii,jj)+MsBaHead3(ii+1,jj+1)+MsBaHead3(ii+1,jj))/4;
                    MsBaHeadMe4(ii,jj)=(MsBaHead4(ii,jj+1)+MsBaHead4(ii,jj)+MsBaHead4(ii+1,jj+1)+MsBaHead4(ii+1,jj))/4;
                    MsBaTempMe1(ii,jj)=(MsBaTemp1(ii+1,jj)+MsBaTemp1(ii,jj)+MsBaTemp1(ii+1,jj+1)+MsBaTemp1(ii,jj+1))/4;
                    MsBaTempMe2(ii,jj)=(MsBaTemp2(ii+1,jj)+MsBaTemp2(ii,jj)+MsBaTemp2(ii+1,jj+1)+MsBaTemp2(ii,jj+1))/4;
                    MsBaTempMe3(ii,jj)=(MsBaTemp3(ii+1,jj)+MsBaTemp3(ii,jj)+MsBaTemp3(ii+1,jj+1)+MsBaTemp3(ii,jj+1))/4;
                    MsBaTempMe4(ii,jj)=(MsBaTemp4(ii+1,jj)+MsBaTemp4(ii,jj)+MsBaTemp4(ii+1,jj+1)+MsBaTemp4(ii,jj+1))/4;
                end
            end
            
            EleIndex=(i-1)*nh+j;
            MsBasisArray{EleIndex,1}=MsBaHead1;
            MsBasisArray{EleIndex,2}=MsBaHead2;
            MsBasisArray{EleIndex,3}=MsBaHead3;
            MsBasisArray{EleIndex,4}=MsBaHead4;
            MsBasisArray{EleIndex,5}=MsBaTemp1;
            MsBasisArray{EleIndex,6}=MsBaTemp2;
            MsBasisArray{EleIndex,7}=MsBaTemp3;
            MsBasisArray{EleIndex,8}=MsBaTemp4;
            
            MsBasisArrayMe{EleIndex,1}=MsBaHeadMe1;
            MsBasisArrayMe{EleIndex,2}=MsBaHeadMe2;
            MsBasisArrayMe{EleIndex,3}=MsBaHeadMe3;
            MsBasisArrayMe{EleIndex,4}=MsBaHeadMe4;
            MsBasisArrayMe{EleIndex,5}=MsBaTempMe1;
            MsBasisArrayMe{EleIndex,6}=MsBaTempMe2;
            MsBasisArrayMe{EleIndex,7}=MsBaTempMe3;
            MsBasisArrayMe{EleIndex,8}=MsBaTempMe4;
            
            MsBasisArrayGDx{EleIndex,1}=MsBaHeadGDx1;
            MsBasisArrayGDx{EleIndex,2}=MsBaHeadGDx2;
            MsBasisArrayGDx{EleIndex,3}=MsBaHeadGDx3;
            MsBasisArrayGDx{EleIndex,4}=MsBaHeadGDx4;
            MsBasisArrayGDx{EleIndex,5}=MsBaTempGDx1;
            MsBasisArrayGDx{EleIndex,6}=MsBaTempGDx2;
            MsBasisArrayGDx{EleIndex,7}=MsBaTempGDx3;
            MsBasisArrayGDx{EleIndex,8}=MsBaTempGDx4;
            
            MsBasisArrayGDy{EleIndex,1}=MsBaHeadGDy1;
            MsBasisArrayGDy{EleIndex,2}=MsBaHeadGDy2;
            MsBasisArrayGDy{EleIndex,3}=MsBaHeadGDy3;
            MsBasisArrayGDy{EleIndex,4}=MsBaHeadGDy4;
            MsBasisArrayGDy{EleIndex,5}=MsBaTempGDy1;
            MsBasisArrayGDy{EleIndex,6}=MsBaTempGDy2;
            MsBasisArrayGDy{EleIndex,7}=MsBaTempGDy3;
            MsBasisArrayGDy{EleIndex,8}=MsBaTempGDy4;
            
        end
    end 
% % ----------- end multiscale finite element basis -------------------------


%%%%%%%%%%%%%%%%
        

        
        % ------------ start to assemble the finite element method ----------------
        EleIndex=0;
        A=sparse(2*TotalNodeC,2*TotalNodeC);
        B=sparse(2*TotalNodeC,1);
        for i=1:nh
            for j=1:nh

                % -------------------- preparation part --------------------

                EleIndex=EleIndex+1;
                NodeIndex1=MsEleArray(EleIndex,1); NodeIndex2=MsEleArray(EleIndex,2);
                NodeIndex3=MsEleArray(EleIndex,3); NodeIndex4=MsEleArray(EleIndex,4);

                % read the basis function matrix

                MsBaHeadMe1=MsBasisArrayMe{EleIndex,1}; MsBaHeadMe2=MsBasisArrayMe{EleIndex,2};
                MsBaHeadMe3=MsBasisArrayMe{EleIndex,3}; MsBaHeadMe4=MsBasisArrayMe{EleIndex,4};
                
                MsBaTempMe1=MsBasisArrayMe{EleIndex,5}; MsBaTempMe2=MsBasisArrayMe{EleIndex,6};
                MsBaTempMe3=MsBasisArrayMe{EleIndex,7}; MsBaTempMe4=MsBasisArrayMe{EleIndex,8};
                
                % read the gradient matrix

                MsBaHeadGDx1=MsBasisArrayGDx{EleIndex,1}; MsBaHeadGDx2=MsBasisArrayGDx{EleIndex,2};
                MsBaHeadGDx3=MsBasisArrayGDx{EleIndex,3}; MsBaHeadGDx4=MsBasisArrayGDx{EleIndex,4};
                
                MsBaTempGDx1=MsBasisArrayGDx{EleIndex,5}; MsBaTempGDx2=MsBasisArrayGDx{EleIndex,6};
                MsBaTempGDx3=MsBasisArrayGDx{EleIndex,7}; MsBaTempGDx4=MsBasisArrayGDx{EleIndex,8};

                MsBaHeadGDy1=MsBasisArrayGDy{EleIndex,1}; MsBaHeadGDy2=MsBasisArrayGDy{EleIndex,2};
                MsBaHeadGDy3=MsBasisArrayGDy{EleIndex,3}; MsBaHeadGDy4=MsBasisArrayGDy{EleIndex,4};
                
                MsBaTempGDy1=MsBasisArrayGDy{EleIndex,5}; MsBaTempGDy2=MsBasisArrayGDy{EleIndex,6};
                MsBaTempGDy3=MsBasisArrayGDy{EleIndex,7}; MsBaTempGDy4=MsBasisArrayGDy{EleIndex,8};

                % mean soil property across the cross element
                % Arithmetic mean?? Geometical mean?

%                 KmlAve=(KmlC(i,j)+KmlC(i+1,j)+KmlC(i,j+1)+KmlC(i+1,j+1))./4;
%                 DtlAve=(DtlC(i,j)+DtlC(i+1,j)+DtlC(i,j+1)+DtlC(i+1,j+1))./4;
%                 DmvAve=(DmvC(i,j)+DmvC(i+1,j)+DmvC(i,j+1)+DmvC(i+1,j+1))./4;
%                 DtvAve=(DtvC(i,j)+DtvC(i+1,j)+DtvC(i,j+1)+DtvC(i+1,j+1))./4;
%                 LamAve=(LamC(i,j)+LamC(i+1,j)+LamC(i,j+1)+LamC(i+1,j+1))./4;
               
                KmlAve=(KmlC(i,j)*KmlC(i+1,j)*KmlC(i,j+1)*KmlC(i+1,j+1))^0.25;
                DtlAve=(DtlC(i,j)*DtlC(i+1,j)*DtlC(i,j+1)*DtlC(i+1,j+1))^0.25;
                DmvAve=(DmvC(i,j)*DmvC(i+1,j)*DmvC(i,j+1)*DmvC(i+1,j+1))^0.25;
                DtvAve=(DtvC(i,j)*DtvC(i+1,j)*DtvC(i,j+1)*DtvC(i+1,j+1))^0.25;
                LamAve=(LamC(i,j)*LamC(i+1,j)*LamC(i,j+1)*LamC(i+1,j+1))^0.25;
                
                H1Ave=(H1C(i,j)+H1C(i+1,j)+H1C(i,j+1)+H1C(i+1,j+1))./4;
                H2Ave=(H2C(i,j)+H2C(i+1,j)+H2C(i,j+1)+H2C(i+1,j+1))./4;
                T1Ave=(T1C(i,j)+T1C(i+1,j)+T1C(i,j+1)+T1C(i+1,j+1))./4;
                T2Ave=(T2C(i,j)+T2C(i+1,j)+T2C(i,j+1)+T2C(i+1,j+1))./4;

                % advection part: determine the upwind temperature 
                % liquid transfer
                aaaa=KmlAve*(HeadCt(i,j+1)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i+1,j))...
                    +DtlAve*(TempCt(i,j+1)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i+1,j));
                if(aaaa>0)                                  % upwind=right
                    TupWindL(1,1)=TempCt(i,j+1);
                    TupWindL(2,1)=TempCt(i,j+1);
                    TupWindL(3,1)=TempCt(i+1,j+1);
                    TupWindL(4,1)=TempCt(i+1,j+1);
                elseif(aaaa<0)                              % upwind=left
                    TupWindL(1,1)=TempCt(i,j);
                    TupWindL(2,1)=TempCt(i,j);
                    TupWindL(3,1)=TempCt(i+1,j);
                    TupWindL(4,1)=TempCt(i+1,j);
                else                                        % no upwind
                    TupWindL(1,1)=0;
                    TupWindL(2,1)=0;
                    TupWindL(3,1)=0;
                    TupWindL(4,1)=0;
                end
                bbbb=KmlAve*(HeadCt(i+1,j)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i,j+1))...
                    +DtlAve*(TempCt(i+1,j)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i,j+1));
                if(bbbb>0)                                  % upwind=up
                    TupWindL(1,2)=TempCt(i+1,j);
                    TupWindL(2,2)=TempCt(i+1,j+1);
                    TupWindL(3,2)=TempCt(i+1,j+1);
                    TupWindL(4,2)=TempCt(i+1,j);
                elseif(bbbb<0)                              % upwind=down
                    TupWindL(1,2)=TempCt(i,j);
                    TupWindL(2,2)=TempCt(i,j+1);
                    TupWindL(3,2)=TempCt(i,j+1);
                    TupWindL(4,2)=TempCt(i,j);
                else                                        % no upwind
                    TupWindL(1,2)=0;
                    TupWindL(2,2)=0;
                    TupWindL(3,2)=0;
                    TupWindL(4,2)=0;
                end
                % vapor transfer
                cccc=DmvAve*(HeadCt(i,j+1)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i+1,j))...
                    +DtvAve*(TempCt(i,j+1)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i+1,j));
                if(cccc>0)                                  % upwind=right
                    TupWindV(1,1)=TempCt(i,j+1);
                    TupWindV(2,1)=TempCt(i,j+1);
                    TupWindV(3,1)=TempCt(i+1,j+1);
                    TupWindV(4,1)=TempCt(i+1,j+1);
                elseif(cccc<0)                              % upwind=left
                    TupWindV(1,1)=TempCt(i,j);
                    TupWindV(2,1)=TempCt(i,j);
                    TupWindV(3,1)=TempCt(i+1,j);
                    TupWindV(4,1)=TempCt(i+1,j);
                else                                        % no upwind
                    TupWindV(1,1)=0;
                    TupWindV(2,1)=0;
                    TupWindV(3,1)=0;
                    TupWindV(4,1)=0;
                end
                dddd=DmvAve*(HeadCt(i+1,j)-HeadCt(i,j)+HeadCt(i+1,j+1)-HeadCt(i,j+1))...
                    +DtvAve*(TempCt(i+1,j)-TempCt(i,j)+TempCt(i+1,j+1)-TempCt(i,j+1));
                if(dddd>0)                                  % upwind=up
                    TupWindV(1,2)=TempCt(i+1,j);
                    TupWindV(2,2)=TempCt(i+1,j+1);
                    TupWindV(3,2)=TempCt(i+1,j+1);
                    TupWindV(4,2)=TempCt(i+1,j);
                elseif(dddd<0)                              % upwind=down
                    TupWindV(1,2)=TempCt(i,j);
                    TupWindV(2,2)=TempCt(i,j+1);
                    TupWindV(3,2)=TempCt(i,j+1);
                    TupWindV(4,2)=TempCt(i,j);
                else                                        % no upwind
                    TupWindV(1,2)=0;
                    TupWindV(2,2)=0;
                    TupWindV(3,2)=0;
                    TupWindV(4,2)=0;
                end

                % -------------------- establish linear system --------------------

                % constructing the diffusive part based on MsFEM
                % Node 1
                if(MsNodeArray(i,j,2)==0)  % no need to consider the boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=B(NodeIndex1+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix: diffusion part

                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx1,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy1,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx1,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy1,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx1,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy1,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx1,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy1,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                    
                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx1,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy1,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx1,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy1,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx1,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy1,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx1,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy1,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;

                    % vapor part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;

                    A(NodeIndex1+TotalNodeC,NodeIndex1)=A(NodeIndex1+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2)=A(NodeIndex1+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3)=A(NodeIndex1+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4)=A(NodeIndex1+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx1,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy1,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                    
                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                    A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                    A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                    A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex1+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;

                elseif(MsNodeArray(i,j,2)==1)  % bottom boundary  

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=TDown;

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i,j,2)==2)  % upper boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe1,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe1,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe1,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe1,'all').*dhf2;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex1+TotalNodeC,NodeIndex1+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex1,1)=B(NodeIndex1,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex1+TotalNodeC,1)=TUp;                


                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx1+MsBaHeadGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx1+MsBaHeadGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx1+MsBaHeadGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx1+MsBaHeadGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1)=A(NodeIndex1,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2)=A(NodeIndex1,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3)=A(NodeIndex1,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex1,NodeIndex4)=A(NodeIndex1,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx1+MsBaTempGDy1.*MsTestGDy1,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx1+MsBaTempGDy2.*MsTestGDy1,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx1+MsBaTempGDy3.*MsTestGDy1,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx1+MsBaTempGDy4.*MsTestGDy1,'all').*dhf2.*dt;

                    A(NodeIndex1,NodeIndex1+TotalNodeC)=A(NodeIndex1,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex1,NodeIndex2+TotalNodeC)=A(NodeIndex1,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex1,NodeIndex3+TotalNodeC)=A(NodeIndex1,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex1,NodeIndex4+TotalNodeC)=A(NodeIndex1,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 2
                if(MsNodeArray(i,j+1,2)==0)  % no need to consider the boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=B(NodeIndex2+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx2,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy2,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx2,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy2,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx2,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy2,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx2,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy2,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx2,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy2,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx2,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy2,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx2,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy2,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx2,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy2,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                    
                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;

                    % vapor part
                
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;

                    A(NodeIndex2+TotalNodeC,NodeIndex1)=A(NodeIndex2+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2)=A(NodeIndex2+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3)=A(NodeIndex2+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4)=A(NodeIndex2+TotalNodeC,NodeIndex4)+DmvAve*dddd;

                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx2,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy2,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;

                    A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                    A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                    A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex2+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;

                elseif(MsNodeArray(i,j+1,2)==1)  % bottom boundary  

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=TDown;


                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i,j+1,2)==2)  % upper boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe2,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe2,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe2,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe2,'all').*dhf2;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex2+TotalNodeC,NodeIndex2+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex2,1)=B(NodeIndex2,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex2+TotalNodeC,1)=TUp; 

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx2+MsBaHeadGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx2+MsBaHeadGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx2+MsBaHeadGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx2+MsBaHeadGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1)=A(NodeIndex2,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2)=A(NodeIndex2,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3)=A(NodeIndex2,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex2,NodeIndex4)=A(NodeIndex2,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx2+MsBaTempGDy1.*MsTestGDy2,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx2+MsBaTempGDy2.*MsTestGDy2,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx2+MsBaTempGDy3.*MsTestGDy2,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx2+MsBaTempGDy4.*MsTestGDy2,'all').*dhf2.*dt;

                    A(NodeIndex2,NodeIndex1+TotalNodeC)=A(NodeIndex2,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex2,NodeIndex2+TotalNodeC)=A(NodeIndex2,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex2,NodeIndex3+TotalNodeC)=A(NodeIndex2,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex2,NodeIndex4+TotalNodeC)=A(NodeIndex2,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 3
                if(MsNodeArray(i+1,j+1,2)==0)  % no need to consider the boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=B(NodeIndex3+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx3,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy3,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx3,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy3,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx3,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy3,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx3,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy3,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                    
                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx3,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy3,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx3,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy3,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx3,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy3,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx3,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy3,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
   
                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;


                    % vapor part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                    
                    A(NodeIndex3+TotalNodeC,NodeIndex1)=A(NodeIndex3+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2)=A(NodeIndex3+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3)=A(NodeIndex3+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4)=A(NodeIndex3+TotalNodeC,NodeIndex4)+DmvAve*dddd;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx3,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy3,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;


                    A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                    A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                    A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex3+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;

                elseif(MsNodeArray(i+1,j+1,2)==1)  % bottom boundary  

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=TDown;

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i+1,j+1,2)==2)  % upper boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe3,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe3,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe3,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe3,'all').*dhf2;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex3+TotalNodeC,NodeIndex3+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex3,1)=B(NodeIndex3,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex3+TotalNodeC,1)=TUp;


                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx3+MsBaHeadGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx3+MsBaHeadGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx3+MsBaHeadGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx3+MsBaHeadGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1)=A(NodeIndex3,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2)=A(NodeIndex3,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3)=A(NodeIndex3,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex3,NodeIndex4)=A(NodeIndex3,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx3+MsBaTempGDy1.*MsTestGDy3,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx3+MsBaTempGDy2.*MsTestGDy3,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx3+MsBaTempGDy3.*MsTestGDy3,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx3+MsBaTempGDy4.*MsTestGDy3,'all').*dhf2.*dt;

                    A(NodeIndex3,NodeIndex1+TotalNodeC)=A(NodeIndex3,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex3,NodeIndex2+TotalNodeC)=A(NodeIndex3,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex3,NodeIndex3+TotalNodeC)=A(NodeIndex3,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex3,NodeIndex4+TotalNodeC)=A(NodeIndex3,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

                % Node 4
                if(MsNodeArray(i+1,j,2)==0)  % no need to consider the boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+T2Ave*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+T2Ave*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+T2Ave*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+T2Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)...
                        +T2Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));

                    aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+T1Ave*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+T1Ave*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+T1Ave*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+T1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=B(NodeIndex4+TotalNodeC,1)+...
                        +T1Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));


                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+LamAve*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+LamAve*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+LamAve*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+LamAve*dddd;

                    % stiffness matrix: advection part

                    % liquid part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx4,'all').*(TupWindL(1,1)-T_0)+sum(MsBaHeadGDy1.*MsTestGDy4,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx4,'all').*(TupWindL(2,1)-T_0)+sum(MsBaHeadGDy2.*MsTestGDy4,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx4,'all').*(TupWindL(3,1)-T_0)+sum(MsBaHeadGDy3.*MsTestGDy4,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx4,'all').*(TupWindL(4,1)-T_0)+sum(MsBaHeadGDy4.*MsTestGDy4,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                
                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+KmlAve*aaaa*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+KmlAve*bbbb*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+KmlAve*cccc*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+KmlAve*dddd*rho_l*c_l;
                    
                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx4,'all').*(TupWindL(1,1)-T_0)+sum(MsBaTempGDy1.*MsTestGDy4,'all').*(TupWindL(1,2)-T_0)).*dhf2.*dt;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx4,'all').*(TupWindL(2,1)-T_0)+sum(MsBaTempGDy2.*MsTestGDy4,'all').*(TupWindL(2,2)-T_0)).*dhf2.*dt;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx4,'all').*(TupWindL(3,1)-T_0)+sum(MsBaTempGDy3.*MsTestGDy4,'all').*(TupWindL(3,2)-T_0)).*dhf2.*dt;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx4,'all').*(TupWindL(4,1)-T_0)+sum(MsBaTempGDy4.*MsTestGDy4,'all').*(TupWindL(4,2)-T_0)).*dhf2.*dt;
                    
                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtlAve*aaaa*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtlAve*bbbb*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtlAve*cccc*rho_l*c_l;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtlAve*dddd*rho_l*c_l;

                    % vapor part
                    
                    aaaa=(sum(MsBaHeadGDx1.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaHeadGDy1.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaHeadGDx2.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaHeadGDy2.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaHeadGDx3.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaHeadGDy3.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaHeadGDx4.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaHeadGDy4.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;

                    A(NodeIndex4+TotalNodeC,NodeIndex1)=A(NodeIndex4+TotalNodeC,NodeIndex1)+DmvAve*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2)=A(NodeIndex4+TotalNodeC,NodeIndex2)+DmvAve*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3)=A(NodeIndex4+TotalNodeC,NodeIndex3)+DmvAve*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4)=A(NodeIndex4+TotalNodeC,NodeIndex4)+DmvAve*dddd;                

                    aaaa=(sum(MsBaTempGDx1.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(1,1)-T_0))+sum(MsBaTempGDy1.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(1,2)-T_0))).*dhf2.*dt.*rho_l;
                    bbbb=(sum(MsBaTempGDx2.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(2,1)-T_0))+sum(MsBaTempGDy2.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(2,2)-T_0))).*dhf2.*dt.*rho_l;
                    cccc=(sum(MsBaTempGDx3.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(3,1)-T_0))+sum(MsBaTempGDy3.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(3,2)-T_0))).*dhf2.*dt.*rho_l;
                    dddd=(sum(MsBaTempGDx4.*MsTestGDx4,'all').*(L_0+c_v.*(TupWindV(4,1)-T_0))+sum(MsBaTempGDy4.*MsTestGDy4,'all').*(L_0+c_v.*(TupWindV(4,2)-T_0))).*dhf2.*dt.*rho_l;
                    
                    A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex1+TotalNodeC)+DtvAve*aaaa;
                    A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex2+TotalNodeC)+DtvAve*bbbb;
                    A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex3+TotalNodeC)+DtvAve*cccc;
                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)+DtvAve*dddd;

                elseif(MsNodeArray(i+1,j,2)==1)  % bottom boundary  

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=TDown;


                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;

                elseif(MsNodeArray(i+1,j,2)==2)  % upper boundary

                    % mass matrix part
                    aaaa=sum(MsBaHeadMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaHeadMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaHeadMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaHeadMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+H1Ave*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+H1Ave*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+H1Ave*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+H1Ave*dddd;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H1Ave*(aaaa*HeadC(i,j)+bbbb*HeadC(i,j+1)+cccc*HeadC(i+1,j+1)+dddd*HeadC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=0;

                    aaaa=sum(MsBaTempMe1.*MsTestMe4,'all').*dhf2;
                    bbbb=sum(MsBaTempMe2.*MsTestMe4,'all').*dhf2;
                    cccc=sum(MsBaTempMe3.*MsTestMe4,'all').*dhf2;
                    dddd=sum(MsBaTempMe4.*MsTestMe4,'all').*dhf2;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+H2Ave*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+H2Ave*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+H2Ave*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+H2Ave*dddd;

                    A(NodeIndex4+TotalNodeC,NodeIndex4+TotalNodeC)=1;

                    % mass vector
                    B(NodeIndex4,1)=B(NodeIndex4,1)+H2Ave*(aaaa*TempC(i,j)+bbbb*TempC(i,j+1)+cccc*TempC(i+1,j+1)+dddd*TempC(i+1,j));
                    B(NodeIndex4+TotalNodeC,1)=TUp;

                    % stiffness matrix
                    aaaa=sum(MsBaHeadGDx1.*MsTestGDx4+MsBaHeadGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaHeadGDx2.*MsTestGDx4+MsBaHeadGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaHeadGDx3.*MsTestGDx4+MsBaHeadGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaHeadGDx4.*MsTestGDx4+MsBaHeadGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1)=A(NodeIndex4,NodeIndex1)+(KmlAve+DmvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2)=A(NodeIndex4,NodeIndex2)+(KmlAve+DmvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3)=A(NodeIndex4,NodeIndex3)+(KmlAve+DmvAve)*cccc;
                    A(NodeIndex4,NodeIndex4)=A(NodeIndex4,NodeIndex4)+(KmlAve+DmvAve)*dddd;

                    aaaa=sum(MsBaTempGDx1.*MsTestGDx4+MsBaTempGDy1.*MsTestGDy4,'all').*dhf2.*dt;
                    bbbb=sum(MsBaTempGDx2.*MsTestGDx4+MsBaTempGDy2.*MsTestGDy4,'all').*dhf2.*dt;
                    cccc=sum(MsBaTempGDx3.*MsTestGDx4+MsBaTempGDy3.*MsTestGDy4,'all').*dhf2.*dt;
                    dddd=sum(MsBaTempGDx4.*MsTestGDx4+MsBaTempGDy4.*MsTestGDy4,'all').*dhf2.*dt;

                    A(NodeIndex4,NodeIndex1+TotalNodeC)=A(NodeIndex4,NodeIndex1+TotalNodeC)+(DtlAve+DtvAve)*aaaa;
                    A(NodeIndex4,NodeIndex2+TotalNodeC)=A(NodeIndex4,NodeIndex2+TotalNodeC)+(DtlAve+DtvAve)*bbbb;
                    A(NodeIndex4,NodeIndex3+TotalNodeC)=A(NodeIndex4,NodeIndex3+TotalNodeC)+(DtlAve+DtvAve)*cccc;
                    A(NodeIndex4,NodeIndex4+TotalNodeC)=A(NodeIndex4,NodeIndex4+TotalNodeC)+(DtlAve+DtvAve)*dddd;
                else    
                end

            end
        end
        
        KK=A\B;
    
        for i=1:nh+1
            for j=1:nh+1
                HeadCtt(i,j)=min(KK(MsNodeArray(i,j,1),1),-13.0);
                TempCtt(i,j)=KK(MsNodeArray(i,j,1)+TotalNodeC,1);
            end
        end
        
        % refine the solution to fine grid 200*200
    
        EleIndex=0;
        for i=1:nh
            for j=1:nh
                EleIndex=EleIndex+1;
                MsBaHead1=MsBasisArray{EleIndex,1};
                MsBaHead2=MsBasisArray{EleIndex,2};
                MsBaHead3=MsBasisArray{EleIndex,3};
                MsBaHead4=MsBasisArray{EleIndex,4};
                MsBaTemp1=MsBasisArray{EleIndex,5};
                MsBaTemp2=MsBasisArray{EleIndex,6};
                MsBaTemp3=MsBasisArray{EleIndex,7};
                MsBaTemp4=MsBasisArray{EleIndex,8};

                il=(i-1)*multiscale;
                jl=(j-1)*multiscale;

                for ii=1:multiscale+1
                    for jj=1:multiscale+1
                        Headtt(il+ii,jl+jj)=HeadCtt(i,j)*MsBaHead1(ii,jj)...
                            +HeadCtt(i,j+1)*MsBaHead2(ii,jj)...
                            +HeadCtt(i+1,j+1)*MsBaHead3(ii,jj)...
                            +HeadCtt(i+1,j)*MsBaHead4(ii,jj);
                        Temptt(il+ii,jl+jj)=TempCtt(i,j)*MsBaTemp1(ii,jj)...
                            +TempCtt(i,j+1)*MsBaTemp2(ii,jj)...
                            +TempCtt(i+1,j+1)*MsBaTemp3(ii,jj)...
                            +TempCtt(i+1,j)*MsBaTemp4(ii,jj);
                    end
                end

            end
        end

        
        max1=max(abs(HeadCtt-HeadCpp)./max(abs(HeadCpp),[],'all'),[],'all');
        max2=max(abs(TempCtt-TempCpp)./max(abs(TempCpp),[],'all'),[],'all');
       
        if (max(max1,max2)<epsilon)
            p=6;
            HeadC=HeadCtt;
            TempC=TempCtt;
            
            Head=Headtt;
            Temp=Temptt;
            
            TotalT=TotalT+dt;
            dt=min(dt_max,dt*1.5);
            
            if(SaveThreshold-TotalT>0)
                dt=min(dt,SaveThreshold-TotalT);
            end
            
        end
        
        if p==5
            dt=dt/2;
        end 
       
    end
    
    for i=1:nh+1
        for j=1:nh+1
            ThetaC(i,j)=FunWrc(HeadC(i,j),TempC(i,j),1);
        end
    end
    
    for i=1:nhT+1
        for j=1:nhT+1
            Theta(i,j)=FunWrc(Head(i,j),Temp(i,j),1);
        end
    end
      
    wzjwzjt=toc
      
    
    if TotalT>=SaveThreshold
        ThetaSave(:,TSindex)=reshape(Theta,[],1);
        HeadSave(:,TSindex)=reshape(Head,[],1);
        TmprSave(:,TSindex)=reshape(Temp,[],1);
        ElaspSave(TSindex,1)=wzjwzjt;
        SaveThreshold=SaveThreshold+3600;
        TSindex=TSindex+1;
    end
 
end

xlswrite('multi10.xlsx',ThetaSave,'theta');
xlswrite('multi10.xlsx',HeadSave,'head');
xlswrite('multi10.xlsx',TmprSave,'temp');
xlswrite('multi10.xlsx',ElaspSave,'ElaspTime');

