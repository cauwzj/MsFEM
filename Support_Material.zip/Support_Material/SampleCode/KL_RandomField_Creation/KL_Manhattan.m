clear all
close all
clc


% Manhattan distance
logn_mean=1;
logn_var=1;

sigma=1;
eta=2;

Lxx=10; X=0:0.1:Lxx; LX=length(X);
Lyy=10; Y=0:0.1:Lyy; LY=length(Y);
AreaXY=Lxx*Lyy;

x0=0:0.1:200; Nx=length(x0); solx=zeros(Nx,2); 
CharEqx=@(x) (eta.*eta.*x.*x-1).*sin(x.*Lxx)-2.*eta.*x.*cos(x.*Lxx);
y0=CharEqx(x0);
%plot(x0,y0);

for i=1:Nx
    solx(i,1)=fsolve(CharEqx,x0(i)); clc
    solx(i,2)=CharEqx(solx(i,1));     % verification
end    

j=1;
for i=1:Nx
    if solx(i)>0
        solw(j)=round(solx(i,1),6);
        j=j+1;
    end
end

solw=unique(solw);

solw=sort(solw,'ascend');
Nw=length(solw);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

n=1;
Index=zeros(Nw*Nw,2);
for i=1:Nw
    for j=1:Nw
        Index(n,:)=[i,j];
        EigenV(n)=4*eta*eta*sigma*sigma/((eta*eta*solw(i)*solw(i)+1)*(eta*eta*solw(j)*solw(j)+1));
        n=n+1;
    end
end
[EigenV,Id]=sort(EigenV,'descend');
Index=Index(Id,:);

% plot(EigenV(1:100));

% truncation of the eigen values
truncN=100;

EgFun=cell(1,truncN);
for i=1:truncN
    A=@(x,y) ((eta*solw(Index(i,1))*cos(solw(Index(i,1))*x)+sin(solw(Index(i,1))*x))...
        /sqrt((eta*eta*solw(Index(i,1))*solw(Index(i,1))+1)*Lxx/2+eta))...
        *((eta*solw(Index(i,2))*cos(solw(Index(i,2))*y)+sin(solw(Index(i,2))*y))...
        /sqrt((eta*eta*solw(Index(i,2))*solw(Index(i,2))+1)*Lyy/2+eta));
    EgFun{i}=A;
end

% start to create a log normal random variable
logn_mu=log((logn_mean^2)/sqrt(logn_var+logn_mean^2));
logn_std=sqrt(log(logn_var/(logn_mean^2)+1));

% this is the random part
Sampl=100;
RF=zeros(LX,LY,Sampl);
RFAdjust=zeros(LX,LY,Sampl);
RandVec=lognrnd(logn_mu,logn_std,[truncN,Sampl])-1;

for wzjwzj=1:20
    for ll=1:Sampl
        for i=1:LX
            for j=1:LY
                RF(i,j,ll)=0;
                for k=1:truncN
                    RF(i,j,ll)=RF(i,j,ll)+RandVec(k,ll)*sqrt(EigenV(k))*EgFun{k}(X(i),Y(j));
                end
            end
        end
    end
    for i=1:LX
        for j=1:LY
            RFasVector=squeeze(RF(i,j,:));
            [emCFD,emPosi]=ecdf(RFasVector);
            %plot(emPosi,emCFD,'.')
            [wzjkkk,Id]=sort(RFasVector,'ascend');
            emCFD=emCFD(2:end);
            for ll=1:Sampl
                wzjkkk(Id(ll))=emCFD(ll);
                if(emCFD(ll)>0.99)
                    wzjkkk(Id(ll))=0.99;
                end
                if(emCFD(ll)<0.01)
                    wzjkkk(Id(ll))=0.01;
                end
                
            end
            emCFD=wzjkkk;
            %plot(RFasVector,emCFD,'.')
            RFAdjust(i,j,:)=reshape(logninv(emCFD,logn_mu,logn_std),[1,1,Sampl]);
        end
    end
    RFAdjust=RFAdjust-mean(RFAdjust,3);
    for ll=1:Sampl
        for kk=1:truncN
            tempsum=0.0;
            for i=1:LX
                for j=1:LY 
                    tempsum=tempsum+RFAdjust(i,j,ll)*EgFun{kk}(X(i),Y(j));
                end
            end
            RandVec(kk,ll)=tempsum/sqrt(EigenV(kk))*AreaXY;
        end
    end
    for ll=1:Sampl
        muAdjust=mean(RandVec(:,ll));
        stdAdjust=std(RandVec(:,ll));
        RandVec(:,ll)=(RandVec(:,ll)-muAdjust)./stdAdjust;
    end
end

for ll=1:Sampl
    for i=1:LX
        for j=1:LY
            RF(i,j,ll)=0;
            for k=1:truncN
                RF(i,j,ll)=RF(i,j,ll)+RandVec(k,ll)*sqrt(EigenV(k))*EgFun{k}(X(i),Y(j));
            end
        end
    end
end

RFRes=squeeze(RF(:,:,50))+1;

[Xmesh,Ymesh]=meshgrid(X,Y);
surf(Xmesh,Ymesh,RFRes,'EdgeColor','none')